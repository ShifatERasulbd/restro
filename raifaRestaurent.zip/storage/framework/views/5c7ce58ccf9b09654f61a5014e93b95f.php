<div class="m-header-navbar js-sticky-header-element">
  <div class="m-header">
    <div class="m-header__navbar">
      <div class="m-header__container">
        
        <!-- Flex Group with Logo -->
        <div class="m-flex-group">
          <!-- Logo Item -->
          <div class="m-flex-group__item m-flex-group__item--logo">
            <a href="/" aria-label="Przejdź do strony głównej" class="m-header__logo-link">
              <img src="https://restaumatic-production.imgix.net/uploads/restaurants/352263/logo/1738059535.png?w=200&h=200" alt="U TURKA Kebab logo" class="m-header__logo-img">
            </a>
          </div>

          <!-- Navigation -->
          <div class="m-flex-group__item m-flex-group__item--main">
            <nav class="m-nav js-navigation js-scroll-spy-nav" data-navigation='{"activeClassName": "is-active"}'>
              <ul class="m-nav__list">
                <li class="m-nav__list-item">
                  <a class="m-nav__item" title="Start" href="/">Start</a>
                </li>
                <li class="m-nav__list-item">
                  <a class="m-nav__item" title="Menu" href="menu.php">Menu</a>
                </li>
                <li class="m-nav__list-item">
                  <a class="m-nav__item" title="Promocje" href="/#section-promotions">Promocje</a>
                </li>
                <li class="m-nav__list-item">
                  <a class="m-nav__item" title="O nas" href="/#section-about-us">O nas</a>
                </li>
                <li class="m-nav__list-item">
                  <a class="m-nav__item" title="Opinie" href="/#section-reviews">Opinie</a>
                </li>
                <li class="m-nav__list-item">
                  <a class="m-nav__item" title="Galeria" href="/#section-gallery">Galeria</a>
                </li>
                <li class="m-nav__list-item">
                  <a class="m-nav__item" title="Kontakt" href="/#section-contact">Kontakt</a>
                </li>
              </ul>
            </nav>
          </div>

          <!-- Order & Mobile Menu -->
          <div class="m-flex-group__item u-text-right">
            <ul class="list-inline u-mb0">
              <li class="hidden-xs hidden-sm">
                <a href="menu.php" class="btn btn-default">Zamów online</a>
              </li>
              <li class="visible-xs-block visible-sm-block">
                <div class="m-nav-toggle">
                  <button 
                    type="button" 
                    class="btn btn-default m-nav-toggle__btn js-navigation-toggle" 
                    title="Nawigacja" 
                    aria-controls="responsive-nav" 
                    data-ga-action="Open mobile navigation (hamburger button clicks)">
                    <span class="icon-reorder m-nav-toggle__icon" aria-hidden="true"></span>
                  </button>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <!-- /m-flex-group -->

      </div>
    </div>
  </div>
</div>
<div class="mobile-navigation-backdrop js-navigation-toggle"></div>
<nav id="responsive-nav" class="mobile-navigation mobile-navigation--right js-navigation" data-navigation='{"activeClassName": "is-active"}'>
  
  <!-- Mobile Navigation Header -->
  <header class="mobile-navigation__header">
    <button 
      type="button" 
      class="mobile-navigation-toggle js-navigation-toggle" 
      aria-controls="responsive-nav" 
      title="Zamknij">
      &times;
    </button>

    <ul class="mobile-navigation__inline-list">
      <li class="mobile-navigation__inline-list-item">
        <div class="m-language-select">
          <!-- Language selector content goes here -->
        </div>
      </li>
    </ul>
  </header>

  <!-- Mobile Navigation Links -->
  <ul class="mobile-navigation__list js-scroll-spy-nav">
    <li>
      <a title="Start" href="/">Start</a>
    </li>
    <li>
      <a title="Menu" href="menu.php">Menu</a>
    </li>
    <li>
      <a title="Promocje" href="/#section-promotions">Promocje</a>
    </li>
    <li>
      <a title="O nas" href="/#section-about-us">O nas</a>
    </li>
    <li>
      <a title="Opinie" href="/#section-reviews">Opinie</a>
    </li>
    <li>
      <a title="Galeria" href="/#section-gallery">Galeria</a>
    </li>
    <li>
      <a title="Kontakt" href="/#section-contact">Kontakt</a>
    </li>
  </ul>

</nav>
<?php /**PATH C:\xampp\htdocs\raifaRestaurent\resources\views/frontend/partials/menu-bar.blade.php ENDPATH**/ ?>