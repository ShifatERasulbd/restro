
<?php $__env->startSection('main'); ?>
<section class="section">
    <div class="section-body">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Edit Review</h4>
            </div>

            <form action="<?php echo e(route('customerReview.update')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="card-body">
                <input type="hidden" name="id" value="<?php echo e($customerReview->id); ?>" class="form-control">

                <!-- Customer Name -->
                <div class="form-group row mb-4">
                  <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Customer Name</label>
                  <div class="col-sm-12 col-md-7">
                      <input type="text" name="customerName" value="<?php echo e($customerReview->customerName); ?>" class="form-control">
                  </div>
                </div>

                <!-- Review -->
                <div class="form-group row mb-4">
                  <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Review</label>
                  <div class="col-sm-12 col-md-7">
                    <textarea class="summernote" name="review"><?php echo e($customerReview->review); ?></textarea>
                  </div>
                </div>

                <!-- Submit -->
                <div class="form-group row mb-4">
                  <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                  <div class="col-sm-12 col-md-7">
                      <button type="submit" class="btn btn-primary">Update</button>
                  </div>
                </div>

              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\raifaRestaurent\resources\views/backend/customerReview/edit.blade.php ENDPATH**/ ?>