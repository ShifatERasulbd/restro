
<?php $__env->startSection('main'); ?>
 
    <section class="section">
            <div class="section-body">
                <div class="row">
                <div class="col-12">
                    <div class="card">
                    <div class="card-header">
                        <h4>Sliders</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                        <table id="mainTable" class="table table-striped">
                            <thead>
                            <tr>
                                <th>SL</th>
                                <th>Location Title</th>
                                <th>Location</th>
                                <th>Contact Number Title</th>
                                <th>Contact Number</th>
                                <th>Opening Hour Title</th>
                                <th>Opening Hour</th>
                                <th>Order Title</th>
                              <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $aboutUs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutUs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                         <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($aboutUs->locationTitle); ?></td>
                                        <td><?php echo e($aboutUs->location); ?></td>
                                        <td><?php echo e($aboutUs->contactNumberTitle); ?></td>
                                        <td><?php echo e($aboutUs->contactNumber); ?></td>
                                        <td><?php echo e($aboutUs->openingHoursTitle); ?></td>
                                        <td><?php echo e($aboutUs->openingHours); ?></td>
                                        <td><?php echo e($aboutUs->orderTitle); ?></td>
                                        <td> 
                                          <a href="<?php echo e(route('aboutUs.edit',$aboutUs->id)); ?>" class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                             
                                    </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tfoot>
                        </table>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\raifaRestaurent\resources\views/backend/aboutUs/index.blade.php ENDPATH**/ ?>