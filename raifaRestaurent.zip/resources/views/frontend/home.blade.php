
<!DOCTYPE html>
<html lang="pl" class="no-js">
<head>
  <meta charset="utf-8">
<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="dns-prefetch" href="https://restaumatic-production.imgix.net">
<link rel="preconnect" href="https://restaumatic-production.imgix.net">
<link rel="preconnect" href="//fonts.gstatic.com" crossorigin>

<link rel="preload" as="font" href="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/font/font-awesome-min-ec97639751ebebe81c1d.woff2" type="font/woff2" crossorigin="anonymous">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- home -->

<link rel="shortcut icon" href="https://restaumatic-production.imgix.net/uploads/sites/330407/1738061759.png?auto=compress%2Cformat&amp;crop=focalpoint&amp;fit=max&amp;h=32&amp;w=32" sizes="32x32">
<link rel="icon" href="https://restaumatic-production.imgix.net/uploads/sites/330407/1738061759.png?auto=compress%2Cformat&amp;crop=focalpoint&amp;fit=max&amp;h=192&amp;w=192" sizes="192x192">
<link rel="apple-touch-icon-precomposed" href="https://restaumatic-production.imgix.net/uploads/sites/330407/1738061759.png?auto=compress%2Cformat&amp;crop=focalpoint&amp;fit=max&amp;h=180&amp;w=180">
<meta name="msapplication-TileImage" content="https://restaumatic-production.imgix.net/uploads/sites/330407/1738061759.png?auto=compress%2Cformat&amp;crop=focalpoint&amp;fit=max&amp;h=270&amp;w=270">

  <meta name="google-play-app" content="app-id=com.restaumatic.u_turka_kebab_production">

<link rel='canonical' href='https://www.uturkakebab.com.pl/.env'/>

<meta property="og:title" content="U TURKA Kebab - Zamów i zapłać online - U TURKA Kebab">
<meta property="og:description" content="U TURKA Kebab - Zamów przez internet, zapłac gotówką lub online, dowieziemy do domu i biura">
<meta property="og:type" content="website">
<meta property='og:url' href='https://www.uturkakebab.com.pl/.env'/>



<meta name="google-site-verification" content="dAw_0ytzl53_wNzVHeoO7UZClRN4ONqJRoxTFCTdwTo" />

  <script type='text/javascript'>
  var quotes = ["", '"', "'"];
  var symbols = ['Promise', '$', 'ahoy', 'jQuery', 'I18n', 'moment', 'jigsaw', 'ComboSearch', 'ZiteReader'];
  var msg_templates = ["X is not defined", "Can't find variable: X", "X is undefined"];
  var ignores = [];
  quotes.forEach(function (q) {
    symbols.forEach(function (s) {
      msg_templates.forEach(function (m) {
        ignores.push(m.replace("X", q + s + q));
      });
    });
  });

  function shouldBeTagAsRestaumaticClient(filename){
    return filename.includes("client/js/views") ||
      filename.includes("MenuPageNewCart") ||
      filename.includes("NewCheckout") ||
      filename.includes("NewThankYouPage");
  }


  window.sentryOnLoad = function () {
    Sentry.init({
      dsn: 'https://844eecb5a0da4da99b3918516f5a379d@app.getsentry.com/85290',
      release: "5c3d618fd330d8b4b553b194f86e6697a910878a",
      environment: "production",
      ignoreErrors: ignores.concat([
        /ChunkLoadError/,
        /SecurityError: Failed to read the 'localStorage' property/,
        /Blocked a frame with origin/,
        /__firefox__/,
        /BlockAdBlock/,
        /DataCloneError/,
        // Random plugins/extensions
        'top.GLOBALS',
        // See: http://blog.errorception.com/2012/03/tale-of-unfindable-js-error.html
        'originalCreateNotification',
        'canvas.contentDocument',
        'MyApp_RemoveAllHighlights',
        'http://tt.epicplay.com',
        'http://loading.retry.widdit.com/',
        'atomicFindClose',
        // Facebook borked
        'fb_xd_fragment',
        // ISP "optimizing" proxy - `Cache-Control: no-transform` seems to reduce this. (thanks @acdha)
        // See http://stackoverflow.com/questions/4113268/how-to-stop-javascript-injection-from-vodafone-proxy
        'bmi_SafeAddOnload',
        'EBCallBackMessageReceived',
        // See http://toolbar.conduit.com/Developer/HtmlAndGadget/Methods/JSInjection.aspx
        'conduitPage',
        /License expired/,
        // https://github.com/getsentry/sentry-javascript/issues/3040 (Chrome mobile on IOS)
        /undefined is not an object (evaluating 'window.webkit.messageHandlers.selectedDebugHandler.postMessage')/,
        /evaluating 'e.contentWindow.postMessage'/,
        // bug in mobile safari when parsing json+ld data
        /Object.prototype.hasOwnProperty.call(o,"telephone")/,
        'extractSchemaValuesFromJSONLD',
        // Old browsers
        'ResizeObserver is not defined',
        // Mobile safari bug
        /Load failed/,
        // https://forum.sentry.io/t/unhandledrejection-non-error-promise-rejection-captured-with-value/14062
        "Non-Error exception captured",
        "Non-Error promise rejection captured",
        "window.matchMedia is not a function",
        "Script error"
      ]),
      beforeSend(event) {
        try {
          if (event.exception && event.exception.values.some(v => v.stacktrace.frames.some(st => shouldBeTagAsRestaumaticClient(st.filename)))) {
              if(!event.hasOwnProperty('tags')) event.tags = {};
              event.tags["client.version"] = "new_restaumatic_client";
            }
        } catch(_) { }
        return event;
      },
      allowUrls: [
          /https:\/\/uturkakebab\.com\.pl\//,
        /https:\/\/d2sv10hdj8sfwn\.cloudfront\.net\/production\/pendolino/,
        /js\-agent\.newrelic\.com/
      ]
    });
  }
</script>

<script src='https://js.sentry-cdn.com/844eecb5a0da4da99b3918516f5a379d.min.js' crossorigin="anonymous"></script>


<script type="text/javascript">
  if (!window.Skubacz) {
    var locale = "pl";
    window.Skubacz = {configuration: { locale: locale }};
  }

  function browserSupportsAllFeatures() {
    return window.Promise && window.fetch && window.Symbol && Object.entries && Object.assign;
  }

  function loadScript(src) {
    console.log("Loading script: " + src);
    var js = document.createElement('script');
    js.src = src;
    js.async = false;
    js.onload = function() {
      console.log("Script loaded: " + src);
    };
    js.onerror = function() {
      console.log("Script load error: " + src);
    };
    document.head.appendChild(js);
  }

  function checkBrowserSupport() {
    if (browserSupportsAllFeatures()) {
      console.log("We are in a modern browser, doing nothing ");
    } else {
      console.log("We are in an older browser, loading polyfills");
      loadScript('https://polyfill.io/v3/polyfill.js?features=es5,es6,Object.entries,NodeList.prototype.forEach,fetch&flags=gated');
    }
  }

  checkBrowserSupport();

  document.documentElement.className = document.documentElement.className.replace(/\bno-js\b/,'js'); // 
</script>

<script type="text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){ dataLayer.push(arguments);}
  gtag("consent", "default", {
    'ad_storage': 'denied',
    'ad_user_data': 'denied',
    'ad_personalization': 'denied',
    'analytics_storage': 'denied',
    'wait_for_update': 500
  })
</script>

  
  
  <title>U TURKA Kebab - Zamów i zapłać online - U TURKA Kebab</title>
  <meta name="description" content="U TURKA Kebab - Zamów przez internet, zapłac gotówką lub online, dowieziemy do domu i biura"/>
  <meta name="keywords" content="Zamów online, Dostawa, Dowóz, Płatności online"/>

  
  
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Merriweather:300,400|Berkshire+Swash:400&subset=latin-ext&display=swap" rel="stylesheet">



  <link rel="stylesheet" media="screen" href="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/fiesta-14a5ed3b9c6d1af28fc2.css" />
  <script src="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/fiesta-14a5ed3b9c6d1af28fc2.js" async="async"></script>

  <link href="https://dmbdno5jmf70v.cloudfront.net/uploads/sites/330407/themes/370047/assets/theme-b525643f20d97723171e21be9b9e28b9.css" media="screen" rel="stylesheet" type="text/css">

  
  
  <script type="text/javascript">
    Skubacz.configuration.editing = false;
    Skubacz.configuration.breakpoints = {
      gridFloatBreakpoint: 992,
      smallMin: 640,
      mediumMin: 992,
      extraMediumMin: 1024,
      largeMin: 1400,
      extraLargeMin: 1750
    };
  </script>
</head>
<body class="l-home" data-bs-no-jquery="true">





<script>
  if ("RestaumaticMobileApp" in window && typeof window.RestaumaticMobileApp.isMobileApp === "function" && window.RestaumaticMobileApp.isMobileApp()) {
    document.getElementsByTagName("body")[0].className += " l-mobile-app";
  }
</script>

<!-- Icons -->
<svg xmlns="http://www.w3.org/2000/svg" style="display: none;" class="svg-icons">
  <symbol id="svg-icon-lactose-free" viewBox="0 0 20 20"><g fill="currentColor"><path d="M10 0C4.477 0 0 4.477 0 10c0 5.522 4.477 10 10 10 5.522 0 10-4.478 10-10 0-5.523-4.478-10-10-10zm0 18.941a8.905 8.905 0 0 1-5.938-2.264l2.659-2.656-.003-1.495-3.405 3.401A8.905 8.905 0 0 1 1.058 10c0-4.931 4.012-8.942 8.942-8.942 2.273 0 4.352.855 5.931 2.259l-3.243 3.228.501 1.016 3.493-3.493a8.906 8.906 0 0 1 2.26 5.934c-.001 4.928-4.012 8.939-8.942 8.939z"/><path d="M7.775 16.07h4.933a.57.57 0 0 0 .569-.569V9.874c0-.504-.163-1.265-.369-1.732l-.37-.836c-.145-.327-.44-.825-.59-1.071v-.03H8.534v.044c-.129.234-.396.729-.542 1.04l-.396.848c-.219.467-.39 1.23-.39 1.737v5.627a.57.57 0 0 0 .569.569zm0 0M8.534 5.067h3.414a.57.57 0 0 0 0-1.138H8.534a.57.57 0 0 0 0 1.138zm0 0"/></g></symbol>
  <symbol id="svg-icon-gluten-free" viewBox="0 0 20 20"><g fill="currentColor"><path d="M10.523 14.026l2.686-.294 2.271 2.267.537-.534-2.273-2.266.295-2.678-6.54-6.522-.537.534.862.86-.189 1.715-2.189-2.184-.536.534L7.1 7.642l-1.719.189-.862-.86-.537.534 6.541 6.521zm-.393-4.432l.189-1.713 1.121 1.116-.189 1.714-1.121-1.117zm.584 1.652l-1.719.188-1.119-1.116 1.718-.188 1.12 1.116zM7.786 8.327l1.121 1.116-1.719.189-1.12-1.116 1.718-.189zm.726-2.248l1.12 1.117-.19 1.713-1.12-1.117.19-1.713zm4.547 6.435l-1.121-1.116.188-1.714 1.121 1.116-.188 1.714zm-2.257.721l-1.12-1.116 1.718-.188 1.121 1.116-1.719.188zm1.719-.187"/><path d="M10 0C4.461 0-.029 4.477-.029 10c0 5.522 4.49 10 10.029 10s10.029-4.479 10.029-10c0-5.523-4.49-10-10.029-10zm0 18.939a8.942 8.942 0 0 1-5.95-2.258l4.142-4.13-.752-.75-4.141 4.131A8.884 8.884 0 0 1 1.032 10c0-4.93 4.023-8.941 8.968-8.941 2.281 0 4.365.855 5.949 2.259L11.855 7.4l.752.749 4.094-4.081a8.881 8.881 0 0 1 2.268 5.933c0 4.93-4.024 8.938-8.969 8.938z"/></g></symbol>
  <symbol id="svg-icon-sea-food" viewBox="0 0 20 20"><g fill="currentColor"><path d="M10 1.058c4.931 0 8.941 4.012 8.941 8.942 0 4.93-4.011 8.941-8.941 8.941-4.93 0-8.942-4.011-8.942-8.941 0-4.93 4.012-8.942 8.942-8.942M10 0C4.477 0 0 4.477 0 10c0 5.522 4.477 10 10 10 5.522 0 10-4.478 10-10 0-5.523-4.478-10-10-10z"/><path d="M4.089 9.695c.435.934-.702 1.498-1.017 2.158-.016.034-.015.059.001.074.184.196 2.42-.727 2.959-.998.162-.082.39-.251.477-.18.649.53 1.739 1.148 3.118 1.541.035.01.069.046.027.093l-.621.494s-.059.039.065.074c.142.039.454.077 1.109.189 1.239.211 2.467-.576 2.562-.587 1.167-.122 1.903-.518 1.903-.518.063-.027.054-.11.018-.127-.209-.174-.576-.333-.578-.528 0-.007.011-.039.025-.042.011-.002.029.004.057.017.027.012.72.272.817.302.363.109.528-.01.551-.006 1.084-.514 1.381-.883 1.381-1.433 0-.82-1.91-2.894-4.734-2.99-.124-.016-.187-.042-.247-.063l-.527-.188c-1.036-.369-2.232.033-2.52.126-.06.02-.014.059-.014.059l.581.406c.039.036.01.053-.012.06-1.356.436-2.384 1.218-3.09 1.658-.14.087-.352-.027-.352-.027s-1.218-.587-1.817-.988a6.913 6.913 0 0 0-.663-.403c-.913-.416-.273.611-.263.627l.004.007c.056.092.116.187.178.281v.001c.275.415.577.817.622.911zm10.566-.063a.364.364 0 0 1-.36-.367c0-.203.161-.367.36-.367s.36.164.36.367a.363.363 0 0 1-.36.367zm-1.611 2.087c-2.238-2.012-.327-3.522-.133-3.756.019-.023.02.006.02.006s-.545 1.002-.49 1.82a4.39 4.39 0 0 0 .635 1.937c.011.043-.011.012-.032-.007zm0 0"/></g></symbol>
  <symbol id="svg-icon-vegan" viewBox="0 0 20 20"><g fill="currentColor"><path d="M10 1.059c4.93 0 8.942 4.011 8.942 8.942 0 4.93-4.012 8.941-8.942 8.941S1.058 14.931 1.058 10c0-4.93 4.011-8.941 8.942-8.941M10 0C4.477 0 0 4.477 0 10c0 5.522 4.477 10 10 10s10-4.478 10-10c0-5.523-4.478-10-10-10z"/><path d="M15.239 6.478h-1.185l.927-.927a.365.365 0 1 0-.518-.517l-.927.927V4.776a.364.364 0 1 0-.73 0v1.305c-1.051-.682-2.285-.721-2.994-.013a8.871 8.871 0 0 0-.48.555l.738.738a.365.365 0 1 1-.516.516l-.68-.68a54.803 54.803 0 0 0-1.33 1.771l.976.977a.364.364 0 0 1-.258.623.366.366 0 0 1-.259-.107l-.888-.889c-.193.276-.386.557-.574.837-2.438 3.641-2.295 4.564-1.897 4.962.751.752 2.977-.636 3.936-1.232l-.576-.577a.365.365 0 1 1 .517-.517l.69.69a51.728 51.728 0 0 0 2.434-1.702l-.54-.539a.365.365 0 1 1 .517-.517l.613.613c.86-.654 1.513-1.189 1.713-1.389.431-.431.604-1.057.486-1.762a3.245 3.245 0 0 0-.496-1.232h1.302a.366.366 0 0 0 .366-.366.367.367 0 0 0-.367-.363"/></g></symbol>
  <symbol id="svg-icon-fit" viewBox="0 0 20 20"><g fill="currentColor"><path d="M10 1.058c4.931 0 8.941 4.012 8.941 8.942 0 4.93-4.011 8.941-8.941 8.941-4.93 0-8.942-4.011-8.942-8.941 0-4.93 4.012-8.942 8.942-8.942M10 0C4.477 0 0 4.477 0 10c0 5.522 4.477 10 10 10 5.522 0 10-4.478 10-10 0-5.523-4.478-10-10-10z"/><path d="M12.469 10.973a.3.3 0 0 1-.222-.098l-.615-.672-1.358 2.944a.301.301 0 0 1-.273.175l-.013-.001a.3.3 0 0 1-.27-.198L8.396 9.46l-.604 1.335a.3.3 0 0 1-.274.177H5.167c.857 1.476 2.427 2.952 4.669 4.393a.3.3 0 0 0 .325 0c2.243-1.439 3.813-2.917 4.671-4.393h-2.363zm0 0"/><path d="M7.324 10.371l.829-1.834a.3.3 0 0 1 .286-.177.299.299 0 0 1 .271.198l1.324 3.671 1.24-2.69a.301.301 0 0 1 .496-.077l.832.908h2.541c.562-1.249.487-2.236.31-2.867a2.999 2.999 0 0 0-3.442-2.124c-.766.138-1.39.544-1.804 1.174a3.005 3.005 0 0 0-.207.374 2.992 2.992 0 0 0-.207-.373c-.413-.63-1.036-1.036-1.802-1.174a2.998 2.998 0 0 0-3.442 2.124c-.179.631-.253 1.618.308 2.867h2.467zm0 0"/></g></symbol>
  <symbol id="svg-icon-vegetarian" viewBox="0 0 20 20"><g fill="currentColor"><path d="M9.999 1.058c4.931 0 8.942 4.012 8.942 8.942 0 4.93-4.012 8.941-8.942 8.941-4.93 0-8.941-4.012-8.941-8.941 0-4.931 4.011-8.942 8.941-8.942m0-1.058C4.477 0 0 4.477 0 10c0 5.522 4.477 10 9.999 10C15.522 20 20 15.522 20 10 20 4.477 15.522 0 9.999 0z"/><path d="M7.017 6.546C4.58 7.96 4.719 10.263 4.803 11.115c3.148-3.729 7.856-3.548 7.856-3.548s-6.675 2.289-8.635 6.88c-.154.363.727.833.928.406.601-1.277 1.437-2.234 1.437-2.234 1.234.459 3.368.997 4.881-.067 2.01-1.414 1.805-4.55 4.673-6.075.671-.359-5.624-1.848-8.926.069zm0 0"/></g></symbol>
  <symbol id="svg-icon-spicy-1" viewBox="0 0 20 20"><g fill="currentColor"><path d="M10 1.058c4.93 0 8.942 4.012 8.942 8.942 0 4.93-4.012 8.941-8.942 8.941-4.931 0-8.942-4.012-8.942-8.941C1.059 5.069 5.07 1.058 10 1.058M10 0C4.478 0 0 4.477 0 10c0 5.522 4.478 10 10 10s10-4.478 10-10c0-5.523-4.477-10-10-10z"/><path d="M15.443 5.552a.607.607 0 1 0-.846.868c.002.002.201.232.182.674-.009.195-.067.482-.252.853.194.108.374.237.532.393a2.4 2.4 0 0 1 .371.472c.344-.571.538-1.128.561-1.665.042-.992-.487-1.537-.548-1.595zm0 0M13.15 8.41c-.808 0-1.664.402-2.132 1.055-2.396 3.341-4.82 3.513-6.095 3.513-.146 0-.276-.003-.39-.003-.444 0-.633.034-.465.366.398.785 2.212 1.748 4.44 1.748 1.794 0 3.858-.625 5.665-2.469.911-.93 1.249-2.793.318-3.704-.356-.35-.839-.506-1.341-.506zm0 0"/></g></symbol>
  <symbol id="svg-icon-spicy-2" viewBox="0 0 20 20"><g fill="currentColor"><path d="M10 1.058c4.93 0 8.941 4.012 8.941 8.942 0 4.93-4.011 8.941-8.941 8.941-4.931 0-8.942-4.012-8.942-8.941 0-4.931 4.012-8.942 8.942-8.942M10 0C4.477 0 0 4.477 0 10c0 5.522 4.477 10 10 10 5.522 0 10-4.478 10-10 0-5.523-4.478-10-10-10z"/><path d="M15.442 5.552a.605.605 0 1 0-.846.868c.002.002.201.232.183.674-.009.195-.067.482-.253.853.194.108.375.237.533.393a2.4 2.4 0 0 1 .371.472c.344-.571.537-1.128.561-1.665.041-.992-.487-1.537-.549-1.595zm0 0M13.149 8.41c-.807 0-1.663.402-2.131 1.055-2.396 3.341-4.82 3.513-6.095 3.513-.146 0-.276-.003-.39-.003-.444 0-.633.034-.465.366.397.785 2.211 1.748 4.439 1.748 1.795 0 3.858-.625 5.665-2.469.911-.93 1.249-2.793.318-3.704-.355-.35-.838-.506-1.341-.506zm0 0"/><path d="M5.563 11.374c-.045-.59.065-1.929 1.824-2.683 0 0-.653 1.58.232 2.379.641-.501 1.093-1.319 1.139-2.11.133-2.281-1.46-3.482-2.494-4.018a.277.277 0 0 0-.38.365c.4.849.668 2.366-1.041 4.133-.522.539-.097 1.531.72 1.934zm0 0"/></g></symbol>
  <symbol id="svg-icon-spicy-3" viewBox="0 0 20 20"><g fill="currentColor"><path d="M10 1.058c4.931 0 8.941 4.012 8.941 8.942 0 4.93-4.011 8.941-8.941 8.941-4.93 0-8.942-4.012-8.942-8.941 0-4.931 4.012-8.942 8.942-8.942M10 0C4.477 0 0 4.477 0 10c0 5.522 4.477 10 10 10 5.522 0 10-4.478 10-10 0-5.523-4.478-10-10-10z"/><path d="M15.442 5.552a.605.605 0 1 0-.846.868c.002.002.201.232.183.674-.009.195-.067.482-.253.853.194.108.375.237.533.393a2.4 2.4 0 0 1 .371.472c.344-.571.537-1.128.561-1.665.041-.992-.487-1.537-.549-1.595zm0 0M13.149 8.41c-.807 0-1.663.402-2.131 1.055-2.396 3.341-4.82 3.513-6.095 3.513-.146 0-.276-.003-.39-.003-.444 0-.633.034-.465.366.397.785 2.211 1.748 4.439 1.748 1.795 0 3.858-.625 5.665-2.469.911-.93 1.249-2.793.318-3.704-.355-.35-.838-.506-1.341-.506zm0 0"/><path d="M9.074 5.599a.168.168 0 0 0-.196.028.168.168 0 0 0-.036.194c.199.424.344 1.121-.182 1.951-.357-1.526-1.56-2.397-2.397-2.83a.277.277 0 0 0-.38.365c.4.849.668 2.366-1.041 4.133-.521.539-.096 1.53.721 1.934-.045-.59.065-1.929 1.824-2.683 0 0-.653 1.58.232 2.379.641-.501 1.093-1.319 1.139-2.11.003-.051 0-.099.002-.148.137-.327.421-.679 1-.927 0 0-.398.963.141 1.45.392-.305.667-.804.695-1.286.08-1.392-.892-2.124-1.522-2.45z"/></g></symbol>
  <symbol id="svg-icon-restaumatic" viewBox="202.273 450 621.186 125.97"><title>Restaumatic</title><g fill="currentColor"><g><path d="m 360.218,535.5037 v -45.0375 h 5.3614 l 1.4156,5.7478 c 3.9461,-3.8313 8.6925,-5.7478 14.2404,-5.7478 v 6.6056 c -5.3762,0 -9.7367,1.9021 -13.0824,5.7047 v 32.7272 z"/><path d="m 426.573,515.258 h -31.6119 c 0,9.2084 5.3756,13.8116 16.1277,13.8116 4.8322,0 9.2361,-0.4289 13.2109,-1.2867 v 6.4338 c -3.9748,0.8578 -8.8076,1.287 -14.4978,1.287 -15.1841,0 -22.7761,-7.678 -22.7761,-23.0332 0,-14.6693 6.9057,-22.0043 20.7173,-22.0043 14.6406,0 20.9171,8.2647 18.8299,24.7918 z m -31.6119,-6.605 v 0 h 24.3629 c -0.1715,-7.8925 -4.0317,-11.8386 -11.5809,-11.8386 -8.0068,0 -12.2673,3.9461 -12.782,11.8386 z"/><path d="m 437.2103,533.359 v -6.863 c 5.29,1.7158 10.6376,2.5736 16.0421,2.5736 7.1771,0 10.766,-2.1447 10.766,-6.4338 0,-4.0028 -2.5024,-6.0052 -7.5061,-6.0052 h -6.4341 c -9.7225,0 -14.5834,-4.4314 -14.5834,-13.2965 0,-8.5785 6.2476,-12.8679 18.7441,-12.8679 5.3756,0 10.7087,0.7155 15.999,2.1447 v 6.863 c -5.2903,-1.7158 -10.6234,-2.5736 -15.999,-2.5736 -7.492,0 -11.238,2.1447 -11.238,6.4338 0,4.0037 2.359,6.0052 7.0773,6.0052 h 6.4341 c 10.2943,0 15.4414,4.4323 15.4414,13.2965 0,8.5785 -6.2342,12.8679 -18.7013,12.8679 -5.4045,0 -10.7521,-0.7147 -16.0421,-2.1447 z"/><path d="m 482.6769,483.1747 h 4.9754 l 1.7158,7.2915 h 12.1816 v 6.4341 h -10.9378 v 25.8642 c 0,4.2035 1.8156,6.3051 5.4474,6.3051 h 5.4904 v 6.4341 h -7.5492 c -7.5493,0 -11.3236,-4.0459 -11.3236,-12.1388 z"/><path d="m 509.4847,521.9064 c 0,-8.6644 6.0905,-12.9963 18.2722,-12.9963 3.9174,0 7.8346,0.2866 11.7527,0.8581 v -5.1044 c 0,-5.1755 -4.0468,-7.7635 -12.1388,-7.7635 -4.6324,0 -9.3793,0.7155 -14.2404,2.1447 v -6.4341 c 4.8611,-1.4292 9.608,-2.1447 14.2404,-2.1447 13.3826,0 20.0738,4.6619 20.0738,13.9833 v 31.0542 h -4.4609 l -2.7451,-4.4609 c -4.4895,2.9741 -9.3792,4.4609 -14.6692,4.4609 -10.7232,0 -16.0847,-4.5324 -16.0847,-13.5973 z m 18.2722,-6.5625 v 0 c -6.8916,0 -10.3372,2.1447 -10.3372,6.4338 0,4.8617 2.7165,7.2919 8.1497,7.2919 5.4901,0 10.1366,-1.4585 13.9402,-4.375 v -8.4929 c -3.9181,-0.5712 -7.8353,-0.8578 -11.7527,-0.8578 z"/><path d="m 599.1304,490.4662 v 45.0375 h -5.4473 l -1.3726,-5.7479 c -5.4621,3.8322 -10.9522,5.7479 -16.471,5.7479 -10.3515,0 -15.527,-5.59 -15.527,-16.7712 v -28.2663 h 7.9353 v 28.395 c 0,6.6911 3.3168,10.0369 9.951,10.0369 4.5465,0 8.8787,-1.9012 12.9966,-5.7047 v -32.7272 z"/><path d="m 611.9983,535.5037 v -45.0375 h 5.3617 l 1.3294,5.662 c 4.3178,-3.7747 9.0219,-5.662 14.1118,-5.662 6.5199,0 10.9661,2.0591 13.3398,6.1767 4.8898,-4.1176 9.8507,-6.1767 14.8839,-6.1767 10.3513,0 15.527,5.705 15.527,17.1145 v 27.923 h -7.935 v -28.3522 c 0,-6.7195 -2.8309,-10.0797 -8.4929,-10.0797 -4.2321,0 -8.1924,1.9449 -11.8814,5.8334 v 32.5985 h -7.935 v -28.2235 c 0,-6.8051 -2.8026,-10.2084 -8.407,-10.2084 -4.4609,0 -8.4498,1.9449 -11.967,5.8334 v 32.5985 z"/><path d="m 687.2751,521.9064 c 0,-8.6644 6.0908,-12.9963 18.2724,-12.9963 3.9175,0 7.8347,0.2866 11.7525,0.8581 v -5.1044 c 0,-5.1755 -4.0465,-7.7635 -12.1386,-7.7635 -4.6323,0 -9.3792,0.7155 -14.2404,2.1447 v -6.4341 c 4.8612,-1.4292 9.6081,-2.1447 14.2404,-2.1447 13.3827,0 20.0739,4.6619 20.0739,13.9833 v 31.0542 h -4.4609 l -2.7451,-4.4609 c -4.4895,2.9741 -9.3793,4.4609 -14.6693,4.4609 -10.7231,0 -16.0849,-4.5324 -16.0849,-13.5973 z m 18.2724,-6.5625 v 0 c -6.8916,0 -10.3371,2.1447 -10.3371,6.4338 0,4.8617 2.7162,7.2919 8.1496,7.2919 5.4902,0 10.1367,-1.4585 13.94,-4.375 v -8.4929 c -3.9178,-0.5712 -7.835,-0.8578 -11.7525,-0.8578 z"/><path d="m 738.1031,483.1747 h 4.9757 l 1.7155,7.2915 h 12.1816 v 6.4341 h -10.9377 v 25.8642 c 0,4.2035 1.8158,6.3051 5.4476,6.3051 h 5.4901 v 6.4341 h -7.5492 c -7.5489,0 -11.3236,-4.0459 -11.3236,-12.1388 z"/><path d="m 775.8487,474.167 v 7.5064 h -7.935 v -7.5064 z m 0,16.2992 v 0 45.0375 h -7.935 v -45.0375 z"/><path d="m 823.4597,534.2167 c -3.7173,0.8578 -7.7207,1.287 -12.0098,1.287 -16.0138,0 -24.0199,-7.7922 -24.0199,-23.3765 0,-14.4403 8.0061,-21.661 24.0199,-21.661 4.2891,0 8.2925,0.4292 12.0098,1.287 v 6.4338 c -3.7173,-0.8578 -7.8639,-1.2867 -12.439,-1.2867 -10.4374,0 -15.6557,5.076 -15.6557,15.2269 0,11.2952 5.2183,16.9424 15.6557,16.9424 4.5751,0 8.7217,-0.4289 12.439,-1.2867 z"/></g><path d="M 318.7635,450 H 211.7531 c -5.214,0 -9.4796,4.2661 -9.4796,9.4802 v 107.0101 c 0,5.2138 4.2656,9.4796 9.4796,9.4796 h 107.0104 c 5.2141,0 9.4799,-4.2658 9.4799,-9.4796 V 459.4802 c 0,-5.2141 -4.2658,-9.4802 -9.4799,-9.4802 z m -8.7004,88.2394 v 0 c 0,0.8183 -0.8858,1.3294 -1.5942,0.9204 l -43.2082,-24.9458 -43.2031,24.9432 c -0.7104,0.4102 -1.5987,-0.1026 -1.5987,-0.9226 v -50.499 c 0,-0.8203 0.8883,-1.3328 1.5987,-0.9229 l 43.2037,24.9437 43.2076,-24.946 c 0.7084,-0.409 1.5942,0.1023 1.5942,0.9207 z"/></g></symbol>
  <symbol id="svg-icon-arrow-right" viewBox="0 0 16 16"><title>Arrow icon</title><g fill="currentColor"><path d="M16 7.8C16 7.8 16 7.8 16 7.8 16 7.8 16 7.7 16 7.7 16 7.6 16 7.6 16 7.5 16 7.5 16 7.5 16 7.5 15.9 7.5 15.9 7.5 15.9 7.4 15.9 7.4 15.9 7.4 15.9 7.4L7.6 0.1C7.4 0 7.2 0 7.1 0.1 7 0.3 7 0.5 7.1 0.6L14.8 7.3 0.3 7.3C0.1 7.3 0 7.5 0 7.7 0 7.9 0.1 8 0.3 8L14.8 8 7.1 14.8C7 14.9 7 15.1 7.1 15.2 7.1 15.3 7.2 15.3 7.3 15.3 7.4 15.3 7.5 15.3 7.6 15.3L15.9 7.9C15.9 7.9 15.9 7.9 15.9 7.9 15.9 7.9 15.9 7.9 16 7.8L16 7.8Z"/></g></symbol>
  <symbol id="svg-icon-ellipsis" viewBox="0 0 36 7"><title>Ellipsis</title><g fill="currentColor"><circle cx="3.5" cy="3.5" r="3.5"/><circle cx="17.909" cy="3.547" r="3.5"/><circle cx="32.5" cy="3.5" r="3.5"/></g></symbol>
  
</svg>


<a href="#main-content" class="m-skip-link">Przejdź do głównej zawartości</a>

  <a href="/#section-menu" class="m-skip-link">Zamów online</a>




  



<div class="notification  js-notify" style="display: none;" role="alert"
   data-notify-key="notification-cms/pages/494802-20250128101229445278"
   data-expiration="1741478400">
   <button type="button" class="notification__close js-notify-close" title="Zamknij" data-ga-action="Banner clicked" data-ga-label="Close button">
      <span aria-hidden="true">&times;</span>
    </button>
   <div class="container">
    <span class="icon-info-sign icon-base" aria-hidden="true"></span> NOWOŚĆ!
    <button class="notification__btn js-notify-close" type="button" data-bs-toggle="modal" data-bs-target="#notification_modal" data-ga-action="Banner clicked" data-ga-label="More button">
      Więcej <span class="icon-angle-right" aria-hidden="true"></span>
    </button>
  </div>
</div>


<noscript>
  <div class="notification notification--error  js-notify is-active" id="notification-no-js" role="alert" data-notify-key="notify-session-no-js">
    <a href="#notification-no-js" role="button" class="notification__close u-color-inherit js-notify-close" title="Zamknij"><span aria-hidden="true">&times;</span></a>
    <div class="container">
      Do prawidłowego działania strony wymagana jest obsługa <strong>JavaScript</strong>. Aby odblokować JavaScript w przeglądarce należy kierować się <a href="http://www.enable-javascript.com/pl/" class="alert-link">tymi instrukcjami</a>.
    </div>
  </div>
</noscript>

<div class="notification notification--error  js-notify js-notify-storage" style="display: none;" id="notification-no-storage" role="alert" data-notify-key="notify-session-storage">
  <button type="button" class="notification__close u-color-inherit js-notify-close" title="Zamknij"><span aria-hidden="true">&times;</span></button>
  <div class="container">
    Do prawidłowego działania strony wymagane są <strong>sessionStorage</strong> oraz <strong>localStorage</strong>. Czy korzystasz z trybu przeglądania prywatnego?
  </div>
</div>

<div class="notification notification--error  js-notify" style="display: none;" id="notification-old-browser" role="alert" data-notify-key="notify-session-old-browser">
  <button type="button" class="notification__close u-color-inherit js-notify-close" title="Zamknij"><span aria-hidden="true">&times;</span></button>
  <div class="container">
    Korzystasz z <strong>przestarzałej przeglądarki</strong>. Prosimy <a href="http://browsehappy.com/" class="alert-link">zaktualizować przeglądarkę</a> w celu bezproblemowego korzystania ze strony.
  </div>
</div>

<div class="js-payment-warning"></div>

































<div id="header" class="m-header m-header--full-coverage m-header--nav-bottom m-header--home">
  <div id="sticky_header" class="m-header__main animated animated--delay-1 fadeIn m-header__main--fancy-top">
    <header class="m-header__navbar">
      <div class="m-header__container m-header__container--navbar">
        <div class="m-flex-group">
  
    
<div class="m-flex-group__item" >
  <a href="/" class="m-header__logo" aria-label="Przejdź do strony głównej">
    <img src="https://restaumatic-production.imgix.net/uploads/restaurants/352263/logo/1738059535.png?auto=compress%2Cformat&amp;crop=focalpoint&amp;fit=clip&amp;h=500&amp;w=500" class="m-header__logo-img" alt="U TURKA Kebab logo">
  </a>
</div>

  
  <div class="m-flex-group__item m-flex-group__item--main">
    
      <nav class="m-nav  js-navigation js-scroll-spy-nav" data-navigation='{"activeClassName": "is-active"}'>
  
    <ul class="m-nav__list">
      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Start" href="/">
      Start
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Menu" href="/#section-menu">
      Menu
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Promocje" href="/#section-promotions">
      Promocje
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="O nas" href="/#section-about-us">
      O nas
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Opinie" href="/#section-reviews">
      Opinie
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Galeria" href="/#section-gallery">
      Galeria
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Kontakt" href="/#section-contact">
      Kontakt
    </a>
  </li>


      
    </ul>
  
</nav>

    
  </div>

  <div class="m-flex-group__item u-text-right">
    <ul class="list-inline u-mb0 ">
      
      
        <li class="hidden-xs hidden-sm">
          <a href="/#section-menu" class="btn btn-default">
            Zamów online
          </a>
        </li>
      
      <li class="visible-xs-block visible-sm-block">
        <div class="m-nav-toggle">
  <button type="button" class="btn btn-default m-nav-toggle__btn js-navigation-toggle" title="Nawigacja" aria-controls="responsive-nav" data-ga-action="Open mobile navigation (hamburger button clicks)">
    <span class="icon-reorder m-nav-toggle__icon" aria-hidden="true"></span>
  </button>
</div>

      </li>
    </ul>
  </div>
</div>

      </div>
    </header>
  </div>

  <section class="m-header__wrapper ">
    
      <div class="m-header__cover-wrapper">
        
          
            
              <div class="m-header__bg-single-img  js-animate__init-element" >
                <img class="m-header__cover " srcset="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/42cd5e28-8d5f-416b-b0cb-c440c12ee46c.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=max&fp-x=0.5&fp-y=0.5&h=1080&rect=0%2C0%2C2000%2C1333&w=1920 1920w, https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/42cd5e28-8d5f-416b-b0cb-c440c12ee46c.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=max&fp-x=0.5&fp-y=0.5&h=auto&rect=0%2C0%2C2000%2C1333&w=1280 1280w, https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/42cd5e28-8d5f-416b-b0cb-c440c12ee46c.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=max&fp-x=0.5&fp-y=0.5&h=auto&rect=0%2C0%2C2000%2C1333&w=768 768w" sizes="100vw" src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/42cd5e28-8d5f-416b-b0cb-c440c12ee46c.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=max&fp-x=0.5&fp-y=0.5&h=1080&rect=0%2C0%2C2000%2C1333&w=1920"  alt="">
              </div>
            
          
        
      </div>
    
    <div class="m-header__content">
      
        <div class="m-header__social-icons m-header__social-icons--left">
          
          
          
          
          
            


  
  
  
  
  <div class="m-icon-group m-icon-group--vertical" >
    <ul class="m-icon-group__list">
      
        <li class="m-icon-group__list-item">
          <a href="https://www.facebook.com/uturkakebab.gmail.eu/" title="Facebook" class="btn btn-primary m-icon-group__item" target="_blank" rel="noopener noreferrer">
            <span class="icon-facebook" aria-hidden="true"></span>
          </a>
        </li>
      
      
      
      
    </ul>
  </div>
  




          
        </div>
      
      
        <div class="m-header__hero ">
          
          
  
  
  
  
  
  
  
  
  
  
  
  
  <div class="m-hero m-hero--media js-slider splide" data-slider='{"asNavFor": "", "type": "fade", "autoplay": false, "interval": 5000}'>
    <div class="splide__track">
      <div class="m-hero__list splide__list" id="header-slider">
        
        
          
          
          
          <article class="m-hero__content splide__slide js-slider__animation-fix">
            <div class="m-header__container">
              <div class="m-hero__row u-mb0">
                <div class="m-hero__col m-hero__col--center">
                  <div class="m-hero__col-inner">
                    
                    <h1 class="m-hero__header" >
                      <span class="m-hero__sup-title animated animated--delay-1 fadeInDown">
                        
                        


  <span class="char" style="--char-index:0">T</span><span class="char" style="--char-index:1">u</span><span class="char" style="--char-index:2">r</span><span class="char" style="--char-index:3">e</span><span class="char" style="--char-index:4">c</span><span class="char" style="--char-index:5">k</span><span class="char" style="--char-index:6">i</span><span class="whitespace"> </span><span class="char" style="--char-index:7">s</span><span class="char" style="--char-index:8">m</span><span class="char" style="--char-index:9">a</span><span class="char" style="--char-index:10">k</span>


                      </span>
                      <span class="m-hero__title m-hero__title--simple animated animated--delay-2 fadeInDown" >
                        
                        


  <span class="char" style="--char-index:0">w</span><span class="whitespace"> </span><span class="char" style="--char-index:1">k</span><span class="char" style="--char-index:2">a</span><span class="char" style="--char-index:3">ż</span><span class="char" style="--char-index:4">d</span><span class="char" style="--char-index:5">y</span><span class="char" style="--char-index:6">m</span><span class="whitespace"> </span><span class="char" style="--char-index:7">k</span><span class="char" style="--char-index:8">ę</span><span class="char" style="--char-index:9">s</span><span class="char" style="--char-index:10">i</span><span class="char" style="--char-index:11">e</span><span class="char" style="--char-index:12">!</span>


                      </span>
                    </h1>

                    
                      <p class="m-hero__description animated animated--delay-3 fadeInDown">
                        
                        


  


                      </p>

                      <p class="m-hero__action animated animated--delay-5 fadeInDown">
                        <a href="/#section-menu"  class="btn btn-primary-on-dark btn-gfb-lg" data-ga-action="Hero button clicked">
                          Zamów online
                        </a>
                      </p>
                    
                  </div>
                </div>
                
                  <aside class="hidden"></aside>
                
              </div>
            </div>
          </article>
        
      </div>
    </div>
    <div class="m-hero__indicators ">
      <div class="m-indicators m-indicators--md-vertical">
        <ul class="m-indicators__dots splide__pagination js-slider__indicators"></ul>
      </div>
    </div>
  </div>



<script>
  (function () {
    var sliderTimeToWait = 0;

    function convertToMs(val) {
      return (String(val).indexOf("ms") === -1) ? parseFloat(val) * 1000 : parseInt(val);
    }

    [].forEach.call(document.querySelectorAll(".js-slider__animation-fix .animated, .js-slider__animation-fix .cell, .js-slider__animation-fix .char"), function (el) {
      var styles = typeof window.getComputedStyle === "function" ? window.getComputedStyle(el) : {};
      var animationTime = convertToMs(styles.animationDuration || "0ms") + convertToMs(styles.animationDelay || "0ms");
      sliderTimeToWait = Math.max(sliderTimeToWait, animationTime);
    });

    window.Skubacz.configuration.slider_animation_fix = {
      animation_time: sliderTimeToWait
    };
  })();
</script>


        </div>
      
      
    </div>
    
  </section>
</div>

<div class="m-header-navbar js-sticky-header-element">
  <div class="m-header">
    <div class="m-header__navbar">
      <div class="m-header__container">
        <div class="m-flex-group">
  
    
<div class="m-flex-group__item" >
  <a href="/" class="m-header__logo" aria-label="Przejdź do strony głównej">
    <img src="https://restaumatic-production.imgix.net/uploads/restaurants/352263/logo/1738059535.png?auto=compress%2Cformat&amp;crop=focalpoint&amp;fit=clip&amp;h=500&amp;w=500" class="m-header__logo-img" alt="U TURKA Kebab logo">
  </a>
</div>

  
  <div class="m-flex-group__item m-flex-group__item--main">
    
      <nav class="m-nav  js-navigation js-scroll-spy-nav" data-navigation='{"activeClassName": "is-active"}'>
  
    <ul class="m-nav__list">
      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Start" href="/">
      Start
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Menu" href="/#section-menu">
      Menu
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Promocje" href="/#section-promotions">
      Promocje
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="O nas" href="/#section-about-us">
      O nas
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Opinie" href="/#section-reviews">
      Opinie
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Galeria" href="/#section-gallery">
      Galeria
    </a>
  </li>


      
        
  <li class="m-nav__list-item">
    <a  class="m-nav__item" title="Kontakt" href="/#section-contact">
      Kontakt
    </a>
  </li>


      
    </ul>
  
</nav>

    
  </div>

  <div class="m-flex-group__item u-text-right">
    <ul class="list-inline u-mb0 ">
      
      
        <li class="hidden-xs hidden-sm">
          <a href="/#section-menu" class="btn btn-default">
            Zamów online
          </a>
        </li>
      
      <li class="visible-xs-block visible-sm-block">
        <div class="m-nav-toggle">
  <button type="button" class="btn btn-default m-nav-toggle__btn js-navigation-toggle" title="Nawigacja" aria-controls="responsive-nav" data-ga-action="Open mobile navigation (hamburger button clicks)">
    <span class="icon-reorder m-nav-toggle__icon" aria-hidden="true"></span>
  </button>
</div>

      </li>
    </ul>
  </div>
</div>

      </div>
    </div>
  </div>
</div>




<div class="mobile-navigation-backdrop js-navigation-toggle"></div>
<nav id="responsive-nav" class="mobile-navigation mobile-navigation--right js-navigation" data-navigation='{"activeClassName": "is-active"}'>
  <header class="mobile-navigation__header">
    <button type="button" class="mobile-navigation-toggle js-navigation-toggle" aria-controls="responsive-nav" title="Zamknij">&times;</button>
    <ul class="mobile-navigation__inline-list">
      
        <li class="mobile-navigation__inline-list-item">
          <div class="m-language-select">
            

          </div>
        </li>
      
    </ul>
  </header>
  <ul class="mobile-navigation__list js-scroll-spy-nav">
    
   
  <li class="">
    <a  class="" title="Start" href="/">
      Start
    </a>
  </li>



   
  <li class="">
    <a  class="" title="Menu" href="/#section-menu">
      Menu
    </a>
  </li>



   
  <li class="">
    <a  class="" title="Promocje" href="/#section-promotions">
      Promocje
    </a>
  </li>



   
  <li class="">
    <a  class="" title="O nas" href="/#section-about-us">
      O nas
    </a>
  </li>



   
  <li class="">
    <a  class="" title="Opinie" href="/#section-reviews">
      Opinie
    </a>
  </li>



   
  <li class="">
    <a  class="" title="Galeria" href="/#section-gallery">
      Galeria
    </a>
  </li>



   
  <li class="">
    <a  class="" title="Kontakt" href="/#section-contact">
      Kontakt
    </a>
  </li>




  </ul>

  

  
</nav>




  
  
  

  <div id="main-content" class="m-main  m-main--nav-bottom">
    


  
    <section id="section-about-us" class="">
      




<div class="m-info-boxes ">
  <ul class="m-info-boxes__list">
    
      <li class="m-info-boxes__item">
        
          <div class="m-info-boxes__icon " >
            <div class="m-icon-item">
              <span class="icon-location" aria-hidden="true"></span>
            </div>
          </div>
        

        <div class="m-info-boxes__content">
          <h2 class="m-heading m-info-boxes__title " >
            Gdzie jesteśmy?
          </h2>

          <p class="m-info-boxes__description " >
            
              U TURKA Kebab<br>
            
            Tadeusza Regera 3<br>
            43-382 Bielsko-Biała
          </p>
        </div>
      </li>
    
    
      <li class="m-info-boxes__item">
        <div class="m-info-boxes__content">
          
            <div class="m-info-boxes__icon " >
              <div class="m-icon-item">
                <span class="icon-phone" aria-hidden="true"></span>
              </div>
            </div>
          

          <h2 class="m-heading m-info-boxes__title " >
            Zadzwoń do nas
          </h2>

          <p class="m-info-boxes__description " >
            
              <a href="tel:739-410-071" class="u-link-unstyled" data-ga-action="phone_click">739 410 071</a>
              
            
          </p>
        </div>
      </li>
    
    <li class="m-info-boxes__item">
      <div class="m-info-boxes__content">
        
          <div class="m-info-boxes__icon " >
            <div class="m-icon-item">
              <span class="icon-time" aria-hidden="true"></span>
            </div>
          </div>
        

        <h2 class="m-heading m-info-boxes__title " >
          Godziny otwarcia
        </h2>

        <div class="m-info-boxes__description " >
          






<div class="m-restaurant-hours  js-restaurant-hours js-restaurant-hours-opening"
  data-restaurant-slug="u-turka-kebab"
  data-active-classes=""
  data-inactive-classes="">

  <div class="m-restaurant-hours__item m-restaurant-hours__item--singular js-restaurant-hours-present-day">
    <span class="m-restaurant-hours__header js-restaurant-hours-header">
      Dzisiaj:&nbsp;
    </span>
    <span class="m-restaurant-hours__data-wrapper">
      <span class="m-restaurant-hours__data js-restaurant-hours-data"></span>
      
        <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab-1756887828532113936000" aria-label="teraz">
          <i class="icon-info-sign"></i>
        </button>
      
      
        <button type="button" class="m-restaurant-hours__btn-collapse js-restaurant-hours-btn-collapse collapsed" data-bs-toggle="collapse" data-bs-target="#opening-hours-collapse-u-turka-kebab-1756887828532113936000" aria-label="Godziny otwarcia" aria-expanded="false">
          <span class="icon-caret-up collapsed__hide"></span>
          <span class="icon-caret-down collapsed__show"></span>
        </button>
      
    </span>
    <span class="clearfix"></span>
  </div>

  <div class="js-restaurant-hours-all-days collapse" id="opening-hours-collapse-u-turka-kebab-1756887828532113936000">
    
      <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="1">
        <span class="m-restaurant-hours__header js-restaurant-hours-header">
          poniedziałek
        </span>
        <span class="m-restaurant-hours__data-wrapper">
          <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
          
            <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab-1756887828532113936000" aria-label="teraz">
              <i class="icon-info-sign"></i>
            </button>
          
        </span>
        <span class="clearfix"></span>
      </div>
    
      <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="2">
        <span class="m-restaurant-hours__header js-restaurant-hours-header">
          wtorek
        </span>
        <span class="m-restaurant-hours__data-wrapper">
          <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
          
            <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab-1756887828532113936000" aria-label="teraz">
              <i class="icon-info-sign"></i>
            </button>
          
        </span>
        <span class="clearfix"></span>
      </div>
    
      <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="3">
        <span class="m-restaurant-hours__header js-restaurant-hours-header">
          środa
        </span>
        <span class="m-restaurant-hours__data-wrapper">
          <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
          
            <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab-1756887828532113936000" aria-label="teraz">
              <i class="icon-info-sign"></i>
            </button>
          
        </span>
        <span class="clearfix"></span>
      </div>
    
      <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="4">
        <span class="m-restaurant-hours__header js-restaurant-hours-header">
          czwartek
        </span>
        <span class="m-restaurant-hours__data-wrapper">
          <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
          
            <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab-1756887828532113936000" aria-label="teraz">
              <i class="icon-info-sign"></i>
            </button>
          
        </span>
        <span class="clearfix"></span>
      </div>
    
      <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="5">
        <span class="m-restaurant-hours__header js-restaurant-hours-header">
          piątek
        </span>
        <span class="m-restaurant-hours__data-wrapper">
          <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
          
            <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab-1756887828532113936000" aria-label="teraz">
              <i class="icon-info-sign"></i>
            </button>
          
        </span>
        <span class="clearfix"></span>
      </div>
    
      <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="6">
        <span class="m-restaurant-hours__header js-restaurant-hours-header">
          sobota
        </span>
        <span class="m-restaurant-hours__data-wrapper">
          <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
          
            <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab-1756887828532113936000" aria-label="teraz">
              <i class="icon-info-sign"></i>
            </button>
          
        </span>
        <span class="clearfix"></span>
      </div>
    
      <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="7">
        <span class="m-restaurant-hours__header js-restaurant-hours-header">
          niedziela
        </span>
        <span class="m-restaurant-hours__data-wrapper">
          <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
          
            <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab-1756887828532113936000" aria-label="teraz">
              <i class="icon-info-sign"></i>
            </button>
          
        </span>
        <span class="clearfix"></span>
      </div>
    
  </div>

  
    <div class="js-restaurant-hours-popover" style="display: none;" id="opening-hours-popover-u-turka-kebab-1756887828532113936000">
  <strong class="pull-left js-restaurant-hours-popover-title"></strong>
  <div class="pull-right m-popover__dismiss">
    <button type="button" class="close js-dismiss-popover" aria-hidden="true">×</button>
  </div>
  <div class="clearfix"></div>
  <div class="js-restaurant-hours-popover-details"></div>
  <div class="js-restaurant-hours-popover-info"></div>
</div>

  

</div>

        </div>
      </div>
    </li>

    
      <li class="m-info-boxes__item">
        <div class="m-info-boxes__content">
          
            <div class="m-info-boxes__icon " >
              <div class="m-icon-item">
                <span class="icon-food" aria-hidden="true"></span>
              </div>
            </div>
          

          <h2 class="m-heading m-info-boxes__title " >
            Zamów online
          </h2>

          <p class="m-info-boxes__action " >
            <a href="/#section-menu"  class="btn btn-primary">Zobacz menu</a>
          </p>
        </div>
      </li>
    
  </ul>
</div>

    </section>
  





  
     <section class="m-section m-section--inner-padding-alt m-section-striped " id="section-info-box">
      





<div class="container">
  <div class="m-info-box ">
    
      <div class="m-info-box__col m-info-box__col--media-last" >
        
          
  <picture class="u-block u-flex-grow">
    <img class="m-info-box__image" src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/5ef4b1c4-679c-4687-8354-26f97cca56e9.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=586&max-w=390&rect=0%2C0%2C718%2C1125"  alt="" loading="lazy" style="aspect-ratio: 390/586;">
  </picture>
  <picture class="u-block u-flex-grow">
    <img class="m-info-box__image m-info-box__image--featured" src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/5ef4b1c4-679c-4687-8354-26f97cca56e9.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=547&max-w=420&rect=1108%2C112%2C619%2C1012"  alt="" loading="lazy" style="aspect-ratio: 420/547;">
  </picture>


        
      </div>
    
    <div class="m-info-box__col ">
      <div class="m-info-box__content " >
        <div class="m-info-box__header">
          <header class="m-page-subheader ">
            <h2 class="m-page-subheader__heading">
              <span class="m-page-subheader__sup-title">
                U TURKA Kebab
              </span>
              <span class="m-page-subheader__title ">
                Bielsko-Biała
              </span>
            </h2>
          </header>
        </div>

        <div class="m-content-box m-info-box__description">
          Jeśli marzysz o soczystym kebabie, który przeniesie Cię w świat orientalnych smaków, zapraszamy U TURKA! Tu znajdziesz wszystko, co najlepsze – od perfekcyjnie przyprawionego mięsa po świeże dodatki i aromatyczne sosy.<br><br>🌟 Przyjdź raz, a wrócisz po więcej! U TURKA Kebab to miejsce, gdzie smaki Orientu łączą się z domowym ciepłem.<br>
        </div>

        <p class="m-info-box__action">
          <a href="/#section-menu"  class="btn btn-primary btn-lg">Menu</a>
        </p>
      </div>
    </div>

    
  </div>
</div>

    </section>
  



  <section class="m-section m-section--inner-padding m-section-striped " id="section-promotions">
    





<div class="m-promo-boxes splide js-slider" data-slider='{"autoplay": false}' data-responsive='{"xsmall": 1, "medium": 2}'>
  
    <header class="m-page-subheader m-page-subheader--center " >
      <h2 class="m-page-subheader__heading">
        <span class="m-page-subheader__sup-title">
          Sprawdź nasze
        </span>
        <span class="m-page-subheader__title">
          Najlepsze Promocje
        </span>
      </h2>

      <p class="m-page-subheader__description">
        <a href="/promocje" class="btn btn-link">Zobacz wszystkie promocje</a>
      </p>
    </header>
  

  <div class="splide__track">
    <div class="m-promo-boxes__list splide__list " >
      
        <article class="m-promo-boxes__list-item splide__slide">
          
          <a href="/#section-menu"  class="m-promo-boxes__item u-link-wrapper">
            <picture class="m-promo-boxes__media ">
              
              
              
              <source srcset="https://restaumatic-production.imgix.net/uploads/media_library/71c4b2d9864b58138785e07cb532d7a2.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=625&max-w=375&rect=0%2C0%2C1960%2C1400" media="(max-width: 1200px)">
              <img class="m-promo-boxes__media-img" src="https://restaumatic-production.imgix.net/uploads/media_library/71c4b2d9864b58138785e07cb532d7a2.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=625&max-w=800&rect=0%2C0%2C1960%2C1400" alt="" loading="lazy">
            </picture>
            <div class="m-promo-boxes__body">
              <div class="m-promo-boxes__body-inner">
                <h3 class="m-heading m-promo-boxes__title">
                  Rabat na pierwsze zamówienie !
                </h3>

                <p class="m-promo-boxes__description">
                  Zamów i zgarnij rabat - 10 %
                </p>

                

                

                <p class="m-promo-boxes__action">
                  
                    <span type="button" class="btn btn-default" tabindex="-1">Zobacz menu</span>
                  
                </p>
              </div>
            </div>
          </a>
        </article>
      
        <article class="m-promo-boxes__list-item splide__slide">
          
          <a href="/#section-menu"  class="m-promo-boxes__item u-link-wrapper">
            <picture class="m-promo-boxes__media ">
              
              
              
              <source srcset="https://restaumatic-production.imgix.net/uploads/media_library/a52f3657cc53670a8a6579c9607bb677.png?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=625&max-w=375&rect=0%2C0%2C1920%2C1920" media="(max-width: 1200px)">
              <img class="m-promo-boxes__media-img" src="https://restaumatic-production.imgix.net/uploads/media_library/a52f3657cc53670a8a6579c9607bb677.png?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=625&max-w=800&rect=0%2C0%2C1920%2C1920" alt="" loading="lazy">
            </picture>
            <div class="m-promo-boxes__body">
              <div class="m-promo-boxes__body-inner">
                <h3 class="m-heading m-promo-boxes__title">
                  6 zamówienie - 15 % RABATU!
                </h3>

                <p class="m-promo-boxes__description">
                  Zgarnij - 15 % RABATU na 6 zamówienie ze strony!
                </p>

                

                

                <p class="m-promo-boxes__action">
                  
                    <span type="button" class="btn btn-default" tabindex="-1">Zobacz menu</span>
                  
                </p>
              </div>
            </div>
          </a>
        </article>
      
    </div>
  </div>

  
    <div class="m-promo-boxes__indicators">
      <div class="m-indicators m-indicators--center">
        <ul class="m-indicators__dots splide__pagination js-slider__indicators"></ul>
      </div>
    </div>
  
</div>

  </section>




  <section class="m-section m-section--inner-padding m-section-striped " id="section-menu">
    <div class="container">
      <header class="m-page-subheader m-page-subheader--center " >
        <h2 class="m-page-subheader__heading">
          <span class="m-page-subheader__sup-title">Dowiedz się więcej</span>
          <span class="m-page-subheader__title">
            O naszym menu
          </span>
        </h2>

        <p class="m-page-subheader__description"></p>
      </header>

      <div class="" >
        










<div id="restaurant-menu" class="restaurant-menu ">
  
  
  
  
  
  
  
  

  

  

  

  

  
  

  

  
      
      <div aria-live="polite" id="alerts-wrapper" class="m-form-wrapper"></div>
      <div id="fulfillment-settings-wrapper" class="m-form-wrapper" aria-live="polite">
        <div class="m-fulfillment-widget m-skeleton js-skeleton u-p2" data-target="#fulfillment-settings" data-area="#fulfillment-settings-wrapper">
          <div class="m-fulfillment-widget__method">
            <div class="m-skeleton__item m-skeleton__item--input"></div>
          </div>
          <div class="m-fulfillment-widget__address">
            <div class="m-skeleton__item m-skeleton__item--input"></div>
          </div>
          <div class="m-fulfillment-widget__time">
            <div class="m-skeleton__item m-skeleton__item--input"></div>
          </div>
        </div>
      </div>
    
  <div id="menu-wrapper" class="m-flex-layout m-flex-layout--column">
    
    

    




<div class="m-flex-layout__aside m-flex-layout__aside--tabs m-flex-layout__aside--sticky  js-sticky-nav">
  <nav class="m-group-nav m-group-nav--tabs js-scroll-spy-nav js-toggle-group-nav">
    <ul class="m-group-nav__list m-group-nav__list--tabs">
      <li class="m-group-nav__arrow m-group-nav__arrow--prev js-group-nav-prev-arrow">
        <button
          type="button"
          class="m-group-nav__arrow-btn u-btn-unstyled"
          aria-label="Poprzednia"
        >
          <i class="icon-btn icon-left" aria-hidden="true"></i>
        </button>
      </li>
      
        <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
            data-visible-in="Site"
          >
            <a href="#menu-kebab-w-totrilli" class="m-group-nav__link js-toggle-group-link is-active">
              
              Kebab w totrilli
              
              
            </a>
          </li>
          
      
        <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
            data-visible-in="Site"
          >
            <a href="#menu-kebab-pita" class="m-group-nav__link js-toggle-group-link ">
              
              Kebab pita
              
              
            </a>
          </li>
          
      
        <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
            data-visible-in="Site"
          >
            <a href="#menu-kebab-w-bulce" class="m-group-nav__link js-toggle-group-link ">
              
              Kebab w bułce
              
              
            </a>
          </li>
          
      
        <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
            data-visible-in="Site"
          >
            <a href="#menu-kebab-w-kubku" class="m-group-nav__link js-toggle-group-link ">
              
              Kebab w kubku
              
              
            </a>
          </li>
          
      
        <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
            data-visible-in="Site"
          >
            <a href="#menu-dania-wegetarianskie" class="m-group-nav__link js-toggle-group-link ">
              
              Dania wegetariańskie
              
              
            </a>
          </li>
          
      
        <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd"
            data-visible-in="Site"
          >
            <a href="#menu-dodatki" class="m-group-nav__link js-toggle-group-link ">
              
              Dodatki
              
              
            </a>
          </li>
          
      
        <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
            data-visible-in="Site"
          >
            <a href="#menu-napoje-bezalkoholowe" class="m-group-nav__link js-toggle-group-link ">
              
              Napoje bezalkoholowe
              
              
            </a>
          </li>
          
      
      <li class="m-group-nav__arrow m-group-nav__arrow--next js-group-nav-next-arrow">
        <button
          type="button"
          class="m-group-nav__arrow-btn u-btn-unstyled"
          aria-label="Następna"
        >
          <i class="icon-btn icon-right" aria-hidden="true"></i>
        </button>
      </li>
    </ul>
  </nav>
</div>


    
      <div class="m-flex-layout__aside ">
        







<nav class="m-group-nav js-toggle-group-nav m-group-nav--horizontal m-group-nav--not-mobile">
  
    <h2 class="sr-only">Menu</h2>
  

  
  <ul class="m-group-nav__list  m-group-nav__list--horizontal">
    
      <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
          data-visible-in="Site"
        >
          <a href="#menu-kebab-w-totrilli" class="m-group-nav__link js-toggle-group-link is-active">
            
  


            Kebab w totrilli
            
            

          </a>
        </li>
        
    
      <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
          data-visible-in="Site"
        >
          <a href="#menu-kebab-pita" class="m-group-nav__link js-toggle-group-link ">
            
  


            Kebab pita
            
            

          </a>
        </li>
        
    
      <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
          data-visible-in="Site"
        >
          <a href="#menu-kebab-w-bulce" class="m-group-nav__link js-toggle-group-link ">
            
  


            Kebab w bułce
            
            

          </a>
        </li>
        
    
      <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
          data-visible-in="Site"
        >
          <a href="#menu-kebab-w-kubku" class="m-group-nav__link js-toggle-group-link ">
            
  


            Kebab w kubku
            
            

          </a>
        </li>
        
    
      <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
          data-visible-in="Site"
        >
          <a href="#menu-dania-wegetarianskie" class="m-group-nav__link js-toggle-group-link ">
            
  


            Dania wegetariańskie
            
            

          </a>
        </li>
        
    
      <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd"
          data-visible-in="Site"
        >
          <a href="#menu-dodatki" class="m-group-nav__link js-toggle-group-link ">
            
  


            Dodatki
            
            

          </a>
        </li>
        
    
      <li class="m-group-nav__list-item js-toggle-group-list-item" data-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
          data-visible-in="Site"
        >
          <a href="#menu-napoje-bezalkoholowe" class="m-group-nav__link js-toggle-group-link ">
            
  


            Napoje bezalkoholowe
            
            

          </a>
        </li>
        
    
  </ul>
</nav>

      </div>
    

    <div class="m-flex-layout__content">
      
      














<div
  class="m-group m-group--full-width js-group"
  data-mode="tab"
  data-mode-mobile=""
  data-accordion-init=close>
  <div class="m-group__list js-toggle-group-nav">
    <div class="js-restaurant-hours" data-restaurant-slug="u-turka-kebab">
      
        

        <h3
          class="m-group__header restaurant-menu__dish-group-name m-group__header--mobile  js-dish-types-hours js-toggle-group-list-item"
          data-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
          data-visible-in="Site">
          <a href="#menu-kebab-w-totrilli" class="m-group__header-link js-toggle-group-link">
            
            <div class="m-group__header-text">
              
              <span>Kebab w totrilli</span>
            </div>
            <span class="m-group__toggle-icon"></span>
          </a>
        </h3>
        <div
          id="menu-kebab-w-totrilli"
          class="menuv2-section m-group__list-item js-group-item m-group__list-item--tab"
          data-visible-in="Site"
          data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3">
          

  <div class="m-list m-list--list m-list--header">
    
      <div class="m-list__featured ">
        

        
      </div>
    

    

    
  </div>
  
    <div class="m-list m-list--list">
      <ul class="m-list__list">
        
          

  <li class="m-list__item "
      data-menu-section-item-id="9bca51b9-8bd7-49c0-b9de-246340bfdc5c"
      data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.34abe148-9976-4caf-96cd-e27fd631bfcf">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="9bca51b9-8bd7-49c0-b9de-246340bfdc5c"
                data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Tortilla
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="9bca51b9-8bd7-49c0-b9de-246340bfdc5c" data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3" data-type="add-menu-product" data-product="34abe148-9976-4caf-96cd-e27fd631bfcf">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.9bca51b9-8bd7-49c0-b9de-246340bfdc5c">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 21,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="b6cf33c6-bfdd-4761-af5a-4b0281493882"
      data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.919aa4c1-d18d-4f65-be66-17f76ed13705">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="b6cf33c6-bfdd-4761-af5a-4b0281493882"
                data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Tortilla z serem
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, ser, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="b6cf33c6-bfdd-4761-af5a-4b0281493882" data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3" data-type="add-menu-product" data-product="919aa4c1-d18d-4f65-be66-17f76ed13705">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.b6cf33c6-bfdd-4761-af5a-4b0281493882">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 25,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="292a3410-276e-49dc-ab2a-b5b68208b8ae"
      data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  highlight-1 ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.5ca68363-b140-4d27-8ebc-dd29b52f2cea">
              
                
                  
                    <span class="m-badge m-badge--success">Nowość</span>
                  
                
              
              
              <span class="js-item__label"
                data-menu-section-item-id="292a3410-276e-49dc-ab2a-b5b68208b8ae"
                data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Tortilla z frytkami
              <span class="dish-icons">
              
                
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, frytki, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="292a3410-276e-49dc-ab2a-b5b68208b8ae" data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3" data-type="add-menu-product" data-product="5ca68363-b140-4d27-8ebc-dd29b52f2cea">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.292a3410-276e-49dc-ab2a-b5b68208b8ae">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 25,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="1a4252f8-7492-4d53-b777-a9939ba0134b"
      data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.0d051fde-27ac-4446-b0e3-f7fbe616c1c8">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="1a4252f8-7492-4d53-b777-a9939ba0134b"
                data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Tortilla samo mięso
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="1a4252f8-7492-4d53-b777-a9939ba0134b" data-menu-section-id="35ef77f2-b815-4eb8-b2ea-64d14dc92ce3" data-type="add-menu-product" data-product="0d051fde-27ac-4446-b0e3-f7fbe616c1c8">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.1a4252f8-7492-4d53-b777-a9939ba0134b">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 30,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
      </ul>
    </div>
  

        </div>
      
        

        <h3
          class="m-group__header restaurant-menu__dish-group-name m-group__header--mobile  js-dish-types-hours js-toggle-group-list-item"
          data-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
          data-visible-in="Site">
          <a href="#menu-kebab-pita" class="m-group__header-link js-toggle-group-link">
            
            <div class="m-group__header-text">
              
              <span>Kebab pita</span>
            </div>
            <span class="m-group__toggle-icon"></span>
          </a>
        </h3>
        <div
          id="menu-kebab-pita"
          class="menuv2-section m-group__list-item js-group-item m-group__list-item--tab"
          data-visible-in="Site"
          data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81">
          

  <div class="m-list m-list--list m-list--header">
    
      <div class="m-list__featured ">
        

        
      </div>
    

    

    
  </div>
  
    <div class="m-list m-list--list">
      <ul class="m-list__list">
        
          

  <li class="m-list__item "
      data-menu-section-item-id="d904c85c-b84e-4849-ab5f-bf7807c202b0"
      data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.03fa89e6-a45f-445d-a3f4-1c5f3b105959">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="d904c85c-b84e-4849-ab5f-bf7807c202b0"
                data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Pita
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="d904c85c-b84e-4849-ab5f-bf7807c202b0" data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81" data-type="add-menu-product" data-product="03fa89e6-a45f-445d-a3f4-1c5f3b105959">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.d904c85c-b84e-4849-ab5f-bf7807c202b0">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 20,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="0f01828a-7da3-42d9-b208-af79681fa67f"
      data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.816003a8-918c-4880-b2ec-7bdb3c8f92b9">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="0f01828a-7da3-42d9-b208-af79681fa67f"
                data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Pita z serem
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, ser, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="0f01828a-7da3-42d9-b208-af79681fa67f" data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81" data-type="add-menu-product" data-product="816003a8-918c-4880-b2ec-7bdb3c8f92b9">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.0f01828a-7da3-42d9-b208-af79681fa67f">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 24,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="f41aab61-03b9-4a63-a343-f9359438977b"
      data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.d8c98b65-9150-4821-ae1f-a1ee5c38e6fc">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="f41aab61-03b9-4a63-a343-f9359438977b"
                data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Pita z frytkami
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, frytki, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="f41aab61-03b9-4a63-a343-f9359438977b" data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81" data-type="add-menu-product" data-product="d8c98b65-9150-4821-ae1f-a1ee5c38e6fc">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.f41aab61-03b9-4a63-a343-f9359438977b">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 24,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="98b1f20d-ac6f-425e-8433-286cf5844a8b"
      data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  highlight-2 ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.283633e2-5467-4637-b29d-610f4c1b9d07">
              
                
                  
                    <span class="m-badge m-badge--info">Szef kuchni poleca</span>
                  
                
              
              
              <span class="js-item__label"
                data-menu-section-item-id="98b1f20d-ac6f-425e-8433-286cf5844a8b"
                data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Pita samo mięso
              <span class="dish-icons">
              
                
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="98b1f20d-ac6f-425e-8433-286cf5844a8b" data-menu-section-id="1e9c073a-4c24-4e50-8a8f-45b897f40c81" data-type="add-menu-product" data-product="283633e2-5467-4637-b29d-610f4c1b9d07">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.98b1f20d-ac6f-425e-8433-286cf5844a8b">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 28,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
      </ul>
    </div>
  

        </div>
      
        

        <h3
          class="m-group__header restaurant-menu__dish-group-name m-group__header--mobile  js-dish-types-hours js-toggle-group-list-item"
          data-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
          data-visible-in="Site">
          <a href="#menu-kebab-w-bulce" class="m-group__header-link js-toggle-group-link">
            
            <div class="m-group__header-text">
              
              <span>Kebab w bułce</span>
            </div>
            <span class="m-group__toggle-icon"></span>
          </a>
        </h3>
        <div
          id="menu-kebab-w-bulce"
          class="menuv2-section m-group__list-item js-group-item m-group__list-item--tab"
          data-visible-in="Site"
          data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557">
          

  <div class="m-list m-list--list m-list--header">
    
      <div class="m-list__featured ">
        

        
      </div>
    

    

    
  </div>
  
    <div class="m-list m-list--list">
      <ul class="m-list__list">
        
          

  <li class="m-list__item "
      data-menu-section-item-id="41edf7da-7a7b-41f3-9d4c-39961c5ff2fa"
      data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.b09c0780-75da-4184-90a7-d2364170fc7a">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="41edf7da-7a7b-41f3-9d4c-39961c5ff2fa"
                data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Bułka
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="41edf7da-7a7b-41f3-9d4c-39961c5ff2fa" data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557" data-type="add-menu-product" data-product="b09c0780-75da-4184-90a7-d2364170fc7a">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.41edf7da-7a7b-41f3-9d4c-39961c5ff2fa">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 25,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="3b95762f-4ed7-437e-933b-7b3a796a3f4a"
      data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.630780bc-1db2-4af3-bcc5-b6929df346a4">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="3b95762f-4ed7-437e-933b-7b3a796a3f4a"
                data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Bułka z serem
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, ser, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="3b95762f-4ed7-437e-933b-7b3a796a3f4a" data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557" data-type="add-menu-product" data-product="630780bc-1db2-4af3-bcc5-b6929df346a4">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.3b95762f-4ed7-437e-933b-7b3a796a3f4a">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 29,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="da6ad3ef-e37b-4711-b68e-e502c17b7392"
      data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.c0ff200d-f0f5-40b1-ad4b-2d5ab7e81284">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="da6ad3ef-e37b-4711-b68e-e502c17b7392"
                data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Bułka z frytkami
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, frytki, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="da6ad3ef-e37b-4711-b68e-e502c17b7392" data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557" data-type="add-menu-product" data-product="c0ff200d-f0f5-40b1-ad4b-2d5ab7e81284">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.da6ad3ef-e37b-4711-b68e-e502c17b7392">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 29,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="253d3ea5-69db-41a0-a551-f8063afadfec"
      data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.d7a36642-92ff-4147-87d9-eaeb9964fb9b">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="253d3ea5-69db-41a0-a551-f8063afadfec"
                data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Bułka samo mięso
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">wołowina, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="253d3ea5-69db-41a0-a551-f8063afadfec" data-menu-section-id="d64c5c73-7ee8-4100-a249-e1bac2bfc557" data-type="add-menu-product" data-product="d7a36642-92ff-4147-87d9-eaeb9964fb9b">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.253d3ea5-69db-41a0-a551-f8063afadfec">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 35,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
      </ul>
    </div>
  

        </div>
      
        

        <h3
          class="m-group__header restaurant-menu__dish-group-name m-group__header--mobile  js-dish-types-hours js-toggle-group-list-item"
          data-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
          data-visible-in="Site">
          <a href="#menu-kebab-w-kubku" class="m-group__header-link js-toggle-group-link">
            
            <div class="m-group__header-text">
              
              <span>Kebab w kubku</span>
            </div>
            <span class="m-group__toggle-icon"></span>
          </a>
        </h3>
        <div
          id="menu-kebab-w-kubku"
          class="menuv2-section m-group__list-item js-group-item m-group__list-item--tab"
          data-visible-in="Site"
          data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5">
          

  <div class="m-list m-list--list m-list--header">
    
      <div class="m-list__featured ">
        

        
      </div>
    

    

    
  </div>
  
    <div class="m-list m-list--list">
      <ul class="m-list__list">
        
          

  <li class="m-list__item "
      data-menu-section-item-id="59e77c88-0a9f-4ae7-b0d3-0749414a1657"
      data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.811e6e8f-1cdd-427a-bb57-478c8a1b63e4">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="59e77c88-0a9f-4ae7-b0d3-0749414a1657"
                data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Kubek
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">mięso, mix sałat, sos, frytki</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="59e77c88-0a9f-4ae7-b0d3-0749414a1657" data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5" data-type="add-menu-product" data-product="811e6e8f-1cdd-427a-bb57-478c8a1b63e4">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.59e77c88-0a9f-4ae7-b0d3-0749414a1657">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 22,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="2622fcb2-7c05-4d86-85a6-07f355fcbc2f"
      data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.db881d12-162b-452f-9b29-404cd69e6311">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="2622fcb2-7c05-4d86-85a6-07f355fcbc2f"
                data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Kubek samo mięso
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">mięso, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="2622fcb2-7c05-4d86-85a6-07f355fcbc2f" data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5" data-type="add-menu-product" data-product="db881d12-162b-452f-9b29-404cd69e6311">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.2622fcb2-7c05-4d86-85a6-07f355fcbc2f">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 40,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="a6fc4562-0907-40bb-9f2a-01fec7ab82d9"
      data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  highlight-3 ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.d990b4ba-25c6-4cc1-a472-ebf6a3a0e7cb">
              
                
                  
                    <span class="m-badge m-badge--info">Oferta specjalna</span>
                  
                
              
              
              <span class="js-item__label"
                data-menu-section-item-id="a6fc4562-0907-40bb-9f2a-01fec7ab82d9"
                data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Zestaw na talerzu XXL
              <span class="dish-icons">
              
                
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">mięso, frytki, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="a6fc4562-0907-40bb-9f2a-01fec7ab82d9" data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5" data-type="add-menu-product" data-product="d990b4ba-25c6-4cc1-a472-ebf6a3a0e7cb">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.a6fc4562-0907-40bb-9f2a-01fec7ab82d9">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  33,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="ff79086e-f246-4ac5-be79-99d9094c92ab"
      data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.64271644-5557-4361-b7da-1f3214ef981d">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="ff79086e-f246-4ac5-be79-99d9094c92ab"
                data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Kapsalon średni
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">mięso, frytki, ser, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="ff79086e-f246-4ac5-be79-99d9094c92ab" data-menu-section-id="ecbabf50-76ac-4f37-b3f8-c24ebe25dde5" data-type="add-menu-product" data-product="64271644-5557-4361-b7da-1f3214ef981d">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.ff79086e-f246-4ac5-be79-99d9094c92ab">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  33,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
      </ul>
    </div>
  

        </div>
      
        

        <h3
          class="m-group__header restaurant-menu__dish-group-name m-group__header--mobile  js-dish-types-hours js-toggle-group-list-item"
          data-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
          data-visible-in="Site">
          <a href="#menu-dania-wegetarianskie" class="m-group__header-link js-toggle-group-link">
            
            <div class="m-group__header-text">
              
              <span>Dania wegetariańskie</span>
            </div>
            <span class="m-group__toggle-icon"></span>
          </a>
        </h3>
        <div
          id="menu-dania-wegetarianskie"
          class="menuv2-section m-group__list-item js-group-item m-group__list-item--tab"
          data-visible-in="Site"
          data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e">
          

  <div class="m-list m-list--list m-list--header">
    
      <div class="m-list__featured ">
        

        
      </div>
    

    

    
  </div>
  
    <div class="m-list m-list--list">
      <ul class="m-list__list">
        
          

  <li class="m-list__item "
      data-menu-section-item-id="aeeabd36-37d8-4d22-be77-1499646df73c"
      data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  vegetarian ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.0fbb0e10-dd8b-4c9b-994b-76b0ce28f556">
              
                
                  
                
              
              
              <span class="js-item__label"
                data-menu-section-item-id="aeeabd36-37d8-4d22-be77-1499646df73c"
                data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Falafel w tortilli
              <span class="dish-icons">
              
                
                  <span class="dish-icons__list-item js-tooltip" title="Wegetariańskie" tabindex="0" role="button">
                    <svg class="svg-icon-vegetarian" width="20" height="20">
                      <use xlink:href="#svg-icon-vegetarian"/>
                    </svg>
                  </span>
                
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">falafel, sałatki, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="aeeabd36-37d8-4d22-be77-1499646df73c" data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e" data-type="add-menu-product" data-product="0fbb0e10-dd8b-4c9b-994b-76b0ce28f556">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.aeeabd36-37d8-4d22-be77-1499646df73c">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 18,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="fac4faaf-607c-48a3-935f-c88ebbffd681"
      data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  vegetarian ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.4d45b9a6-bf8a-4461-8477-5722633cbc16">
              
                
                  
                
              
              
              <span class="js-item__label"
                data-menu-section-item-id="fac4faaf-607c-48a3-935f-c88ebbffd681"
                data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Falafel w kubku
              <span class="dish-icons">
              
                
                  <span class="dish-icons__list-item js-tooltip" title="Wegetariańskie" tabindex="0" role="button">
                    <svg class="svg-icon-vegetarian" width="20" height="20">
                      <use xlink:href="#svg-icon-vegetarian"/>
                    </svg>
                  </span>
                
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">falafel, frytki, mix sałat, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="fac4faaf-607c-48a3-935f-c88ebbffd681" data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e" data-type="add-menu-product" data-product="4d45b9a6-bf8a-4461-8477-5722633cbc16">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.fac4faaf-607c-48a3-935f-c88ebbffd681">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 21,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="203510ac-38eb-4dba-8b34-2e406e961a0d"
      data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  vegetarian ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.99e0e7d2-42c5-4092-bd34-658a32375cd1">
              
                
                  
                
              
              
              <span class="js-item__label"
                data-menu-section-item-id="203510ac-38eb-4dba-8b34-2e406e961a0d"
                data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Wege tortilla
              <span class="dish-icons">
              
                
                  <span class="dish-icons__list-item js-tooltip" title="Wegetariańskie" tabindex="0" role="button">
                    <svg class="svg-icon-vegetarian" width="20" height="20">
                      <use xlink:href="#svg-icon-vegetarian"/>
                    </svg>
                  </span>
                
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">mix sałat, sos, frytki, ser</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="203510ac-38eb-4dba-8b34-2e406e961a0d" data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e" data-type="add-menu-product" data-product="99e0e7d2-42c5-4092-bd34-658a32375cd1">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.203510ac-38eb-4dba-8b34-2e406e961a0d">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 20,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="fa14f9aa-0bcd-4e9d-8d67-c3160bf247b7"
      data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  vegetarian ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.33704fb6-b7d9-4ea3-bfbd-4a8274354b31">
              
                
                  
                
              
              
              <span class="js-item__label"
                data-menu-section-item-id="fa14f9aa-0bcd-4e9d-8d67-c3160bf247b7"
                data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Wege bułka
              <span class="dish-icons">
              
                
                  <span class="dish-icons__list-item js-tooltip" title="Wegetariańskie" tabindex="0" role="button">
                    <svg class="svg-icon-vegetarian" width="20" height="20">
                      <use xlink:href="#svg-icon-vegetarian"/>
                    </svg>
                  </span>
                
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">frytki, ser, sałatki, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="fa14f9aa-0bcd-4e9d-8d67-c3160bf247b7" data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e" data-type="add-menu-product" data-product="33704fb6-b7d9-4ea3-bfbd-4a8274354b31">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.fa14f9aa-0bcd-4e9d-8d67-c3160bf247b7">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 20,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="44451864-16af-4073-8fb3-634754a2409b"
      data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  vegetarian ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.c88ad433-c427-40ca-8e16-5821fc43ffe5">
              
                
                  
                
              
              
              <span class="js-item__label"
                data-menu-section-item-id="44451864-16af-4073-8fb3-634754a2409b"
                data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Wege kubek
              <span class="dish-icons">
              
                
                  <span class="dish-icons__list-item js-tooltip" title="Wegetariańskie" tabindex="0" role="button">
                    <svg class="svg-icon-vegetarian" width="20" height="20">
                      <use xlink:href="#svg-icon-vegetarian"/>
                    </svg>
                  </span>
                
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
            <span class="muted">frytki, ser, sałatki, sos</span>
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="44451864-16af-4073-8fb3-634754a2409b" data-menu-section-id="c9a46218-416b-4cbc-aa76-2cbdf7a2543e" data-type="add-menu-product" data-product="c88ad433-c427-40ca-8e16-5821fc43ffe5">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.44451864-16af-4073-8fb3-634754a2409b">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  od 20,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
      </ul>
    </div>
  

        </div>
      
        

        <h3
          class="m-group__header restaurant-menu__dish-group-name m-group__header--mobile  js-dish-types-hours js-toggle-group-list-item"
          data-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd"
          data-visible-in="Site">
          <a href="#menu-dodatki" class="m-group__header-link js-toggle-group-link">
            
            <div class="m-group__header-text">
              
              <span>Dodatki</span>
            </div>
            <span class="m-group__toggle-icon"></span>
          </a>
        </h3>
        <div
          id="menu-dodatki"
          class="menuv2-section m-group__list-item js-group-item m-group__list-item--tab"
          data-visible-in="Site"
          data-menu-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd">
          

  <div class="m-list m-list--list m-list--header">
    
      <div class="m-list__featured ">
        

        
      </div>
    

    

    
  </div>
  
    <div class="m-list m-list--list">
      <ul class="m-list__list">
        
          

  <li class="m-list__item "
      data-menu-section-item-id="1e5f3510-3f1f-44c1-9a16-7e79efeefd00"
      data-menu-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.3bf582f8-556b-4d2d-b6a0-f0b983546988">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="1e5f3510-3f1f-44c1-9a16-7e79efeefd00"
                data-menu-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Frytki małe 150g
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="1e5f3510-3f1f-44c1-9a16-7e79efeefd00" data-menu-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd" data-type="add-menu-product" data-product="3bf582f8-556b-4d2d-b6a0-f0b983546988">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.1e5f3510-3f1f-44c1-9a16-7e79efeefd00">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  11,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="8cfa7e7a-2b51-4ced-bf84-baf843e0bee5"
      data-menu-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.42f1956f-99ed-43bc-96ea-e0c89a04678f">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="8cfa7e7a-2b51-4ced-bf84-baf843e0bee5"
                data-menu-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Frytki duże 180g
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="8cfa7e7a-2b51-4ced-bf84-baf843e0bee5" data-menu-section-id="1adb52ff-50e3-4d69-9e75-11f2bb28cebd" data-type="add-menu-product" data-product="42f1956f-99ed-43bc-96ea-e0c89a04678f">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.8cfa7e7a-2b51-4ced-bf84-baf843e0bee5">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  14,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
      </ul>
    </div>
  

        </div>
      
        

        <h3
          class="m-group__header restaurant-menu__dish-group-name m-group__header--mobile  js-dish-types-hours js-toggle-group-list-item"
          data-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
          data-visible-in="Site">
          <a href="#menu-napoje-bezalkoholowe" class="m-group__header-link js-toggle-group-link">
            
            <div class="m-group__header-text">
              
              <span>Napoje bezalkoholowe</span>
            </div>
            <span class="m-group__toggle-icon"></span>
          </a>
        </h3>
        <div
          id="menu-napoje-bezalkoholowe"
          class="menuv2-section m-group__list-item js-group-item m-group__list-item--tab"
          data-visible-in="Site"
          data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb">
          

  <div class="m-list m-list--list m-list--header">
    
      <div class="m-list__featured ">
        

        
      </div>
    

    

    
  </div>
  
    <div class="m-list m-list--list">
      <ul class="m-list__list">
        
          

  <li class="m-list__item "
      data-menu-section-item-id="7a7a0d54-1508-49e0-b121-ef32d6c791ec"
      data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.987e7748-7cf7-4a35-a216-f1d1f9ca34c7">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="7a7a0d54-1508-49e0-b121-ef32d6c791ec"
                data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Coca-Cola 0,5l
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="7a7a0d54-1508-49e0-b121-ef32d6c791ec" data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb" data-type="add-menu-product" data-product="987e7748-7cf7-4a35-a216-f1d1f9ca34c7">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.7a7a0d54-1508-49e0-b121-ef32d6c791ec">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  8,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="f6d47d54-8abc-40f7-adb7-823ea2788f92"
      data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.5a155b29-0399-4b5a-a82e-776bc4bd5d29">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="f6d47d54-8abc-40f7-adb7-823ea2788f92"
                data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Fanta Pomarańczowa 0,5l
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="f6d47d54-8abc-40f7-adb7-823ea2788f92" data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb" data-type="add-menu-product" data-product="5a155b29-0399-4b5a-a82e-776bc4bd5d29">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.f6d47d54-8abc-40f7-adb7-823ea2788f92">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  8,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="980d9c2f-85a0-4877-bfe4-a1fdab8ec20e"
      data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.a8b11288-239c-4387-bdce-4513fac5d8a4">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="980d9c2f-85a0-4877-bfe4-a1fdab8ec20e"
                data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Sprite 0,5l
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="980d9c2f-85a0-4877-bfe4-a1fdab8ec20e" data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb" data-type="add-menu-product" data-product="a8b11288-239c-4387-bdce-4513fac5d8a4">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.980d9c2f-85a0-4877-bfe4-a1fdab8ec20e">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  8,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="88f8a50a-de85-4f5a-96b6-93b0ad7f0acd"
      data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.ffc52035-72cb-4d12-8eaa-0ec428dd092f">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="88f8a50a-de85-4f5a-96b6-93b0ad7f0acd"
                data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Cappy 100% sok jabłkowy 0,33l
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="88f8a50a-de85-4f5a-96b6-93b0ad7f0acd" data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb" data-type="add-menu-product" data-product="ffc52035-72cb-4d12-8eaa-0ec428dd092f">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.88f8a50a-de85-4f5a-96b6-93b0ad7f0acd">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  6,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="07dc254e-94ca-49b2-bfbd-79839661c989"
      data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.5b395f5b-faeb-48c1-a5dd-a313f7eca98a">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="07dc254e-94ca-49b2-bfbd-79839661c989"
                data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Cappy 100% sok pomarańczowy 0,33l
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="07dc254e-94ca-49b2-bfbd-79839661c989" data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb" data-type="add-menu-product" data-product="5b395f5b-faeb-48c1-a5dd-a313f7eca98a">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.07dc254e-94ca-49b2-bfbd-79839661c989">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  6,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="fb7d8e57-ffd9-4435-89e1-7cd70222ff26"
      data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.6c72db39-74e3-46dc-9f62-3be07337956f">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="fb7d8e57-ffd9-4435-89e1-7cd70222ff26"
                data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Kropla Beskidu naturalna woda mineralna gazowana 0,5l
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="fb7d8e57-ffd9-4435-89e1-7cd70222ff26" data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb" data-type="add-menu-product" data-product="6c72db39-74e3-46dc-9f62-3be07337956f">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.fb7d8e57-ffd9-4435-89e1-7cd70222ff26">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  5,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
          

  <li class="m-list__item "
      data-menu-section-item-id="9a8167ac-d296-4fe2-9bdd-c2502e294866"
      data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
      data-visible-in="Site"
   >
    
    
    <div class="m-item m-item--list dish  ">
      <div class="m-item__row ">
        
        
        
        

        <div class="m-item__col-header">
          

          <div class="m-item__header">
            <div class="m-item__labels" data-field-id="Menu.labels.0c9eccb6-ff2f-4738-944d-0fbc1d8f7001">
              
              
              <span class="js-item__label"
                data-menu-section-item-id="9a8167ac-d296-4fe2-9bdd-c2502e294866"
                data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb"
                data-availability-schedule-id="">
                  

              </span>
            </div>

            <h4 class="m-item__title restaurant-menu__dish-name">
              Kropla Beskidu naturalna woda mineralna niegazowana 0,5l
              <span class="dish-icons">
              
              </span>
              

            </h4>
          </div>

          <div class="m-item__description">
            
          </div>
        </div>

        


        <div class="m-item__col m-item__col--secondary actions menuv2-cart-button" data-menu-section-item-id="9a8167ac-d296-4fe2-9bdd-c2502e294866" data-menu-section-id="5bf8a30f-4c91-448a-b67e-b2e85a9062cb" data-type="add-menu-product" data-product="0c9eccb6-ff2f-4738-944d-0fbc1d8f7001">
          <button type="button" class="btn add-button u-progress" data-field-id="Menu.add.9a8167ac-d296-4fe2-9bdd-c2502e294866">
            <i class="icon-btn icon-spinner icon-spin u-mr1" aria-hidden="true"></i>
            
            
  5,00 zł


            &nbsp;
          </button>
        </div>
      </div>
    </div>
  </li>


        
      </ul>
    </div>
  

        </div>
      
    </div>
  </div>
</div>

      
    </div>
  </div>
</div>



      </div>
    </div>
  </section>




  <section class="m-section m-section--inner-padding m-section-striped " id="section-reviews">
    




















<div class="m-testimonials ">
  <div class="container">
    
      <header class="m-page-subheader m-page-subheader--center " >
        <h2 class="m-page-subheader__heading">
          <span class="m-page-subheader__sup-title">
            Sprawdź co mówią o nas
          </span>
          <span class="m-page-subheader__title">
            Zadowoleni klienci
          </span>
        </h2>
        <p class="m-page-subheader__description">
          99,2% klientów jest z nas zadowolonych!
        </p>
        <p class="m-page-subheader__description">
          <a href="/opinie"  class="btn btn-link ">Zobacz wszystkie opinie</a>
        </p>
      </header>
    
    <div class="" >
      <div class="m-section m-section--bottom splide js-slider" data-slider='{"autoplay": false}' data-responsive='{"xsmall": 1, "small": 3}'>
        <div class="splide__track">
          <div class="m-testimonials__list splide__list">
            
              <article class="m-testimonials__item splide__slide">
                <p class="m-testimonials__content">
                  
                    Kebab bardzo dobry. Kupuje dosc czesto. Cena spoko. Nie jest to kraft ale lepszy niz u innych. Polecam
                  
                </p>

                <footer class="m-testimonials__footer">
                  <p class="m-heading m-testimonials__author ">
                    Mateusz
                    
                  </p>

                  
                </footer>
              </article>
            
              <article class="m-testimonials__item splide__slide">
                <p class="m-testimonials__content">
                  
                    Wszystko smaczne i ciepłe. Polecam.
                  
                </p>

                <footer class="m-testimonials__footer">
                  <p class="m-heading m-testimonials__author ">
                    Mateusz
                    
                  </p>

                  
                </footer>
              </article>
            
              <article class="m-testimonials__item splide__slide">
                <p class="m-testimonials__content">
                  
                    Zamówienie online bezproblemowe, jedzenie dobre i ciepłe. 
                  
                </p>

                <footer class="m-testimonials__footer">
                  <p class="m-heading m-testimonials__author ">
                    Krzysztof
                    
                  </p>

                  
                </footer>
              </article>
            
              <article class="m-testimonials__item splide__slide">
                <p class="m-testimonials__content">
                  
                    Smacznie, szybka dostawa
                  
                </p>

                <footer class="m-testimonials__footer">
                  <p class="m-heading m-testimonials__author ">
                    Aga
                    
                  </p>

                  
                </footer>
              </article>
            
          </div>
        </div>

        
          <div class="m-testimonials__indicators">
            <div class="m-indicators m-indicators--center">
              <ul class="m-indicators__dots splide__pagination js-slider__indicators"></ul>
            </div>
          </div>
        
      </div>
      
    </div>
  </div>
</div>

  </section>



  <section class="m-section m-section--inner-padding m-section-striped " id="section-gallery">
    




  <div id="gallery-advanced" class="m-advanced-layout">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 m-advanced-layout__col-primary">
          <div class="m-advanced-layout__content-wrapper " >
            <header class="m-page-subheader">
              <h2 class="m-page-subheader__heading">
                <span class="m-page-subheader__sup-title">
                  Zobacz nasze
                </span>
                <span class="m-page-subheader__title">
                  Potrawy i restauracje
                </span>
              </h2>
            </header>

            <div class="m-advanced-layout__content m-advanced-layout__content--cols">
              Zapraszamy do miejsca, gdzie kebab to prawdziwa uczta! U TURKA serwujemy jedynie to, co najlepsze – wyborne mięso, świeże dodatki i autentyczne sosy, które podkreślają smak każdej potrawy. 
            </div>

            <ul class="m-advanced-layout__media-list">
              
                <li class="m-advanced-layout__media-list-item">
                  
                  <a href="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/43c44e79-84b7-4fa5-9372-d44bb0a777c8.jpg?auto=compress%2Cformat&amp;balph=28&amp;blend=ffcc00&amp;blur=0&amp;bm=overlay&amp;crop=focalpoint&amp;fit=max&amp;fp-x=0.5&amp;fp-y=0.5&amp;h=auto&amp;rect=0%2C0%2C2000%2C1333&amp;w=1920" class="m-overlay u-link-wrapper m-advanced-layout__item" data-lightbox="home-gallery-u-turka-kebab">
                    <picture class="m-overlay__item">
                      <img class="m-advanced-layout__item-image" 
                          src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/43c44e79-84b7-4fa5-9372-d44bb0a777c8.jpg?auto=compress%2Cformat&balph=28&blend=ffcc00&blur=0&bm=overlay&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&h=295&rect=0%2C0%2C2000%2C1333&w=325" alt="" style="aspect-ratio: 325/295;" loading="lazy">
                    </picture>
                    <p class="m-overlay__content">
                      <span class="icon-search m-overlay__icon" aria-hidden="true"></span>
                    </p>
                  </a>
                </li>
              
                <li class="m-advanced-layout__media-list-item">
                  
                  <a href="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/25a16b76-da52-4416-a82b-20842970a1e0.jpg?auto=compress%2Cformat&amp;blur=0&amp;crop=focalpoint&amp;fit=max&amp;fp-x=0.5&amp;fp-y=0.5&amp;h=auto&amp;rect=0%2C0%2C1941%2C2000&amp;w=1920" class="m-overlay u-link-wrapper m-advanced-layout__item" data-lightbox="home-gallery-u-turka-kebab">
                    <picture class="m-overlay__item">
                      <img class="m-advanced-layout__item-image" 
                          src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/25a16b76-da52-4416-a82b-20842970a1e0.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&h=295&rect=0%2C0%2C1941%2C2000&w=325" alt="" style="aspect-ratio: 325/295;" loading="lazy">
                    </picture>
                    <p class="m-overlay__content">
                      <span class="icon-search m-overlay__icon" aria-hidden="true"></span>
                    </p>
                  </a>
                </li>
              
                <li class="m-advanced-layout__media-list-item">
                  
                  <a href="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/68845f2f-677a-4d8a-8780-8c87c8c33fde.jpg?auto=compress%2Cformat&amp;blur=0&amp;crop=focalpoint&amp;fit=max&amp;fp-x=0.5&amp;fp-y=0.5&amp;h=auto&amp;rect=621%2C472%2C744%2C816&amp;w=1920" class="m-overlay u-link-wrapper m-advanced-layout__item" data-lightbox="home-gallery-u-turka-kebab">
                    <picture class="m-overlay__item">
                      <img class="m-advanced-layout__item-image" 
                          src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/68845f2f-677a-4d8a-8780-8c87c8c33fde.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&h=295&rect=621%2C472%2C744%2C816&w=325" alt="" style="aspect-ratio: 325/295;" loading="lazy">
                    </picture>
                    <p class="m-overlay__content">
                      <span class="icon-search m-overlay__icon" aria-hidden="true"></span>
                    </p>
                  </a>
                </li>
              
            </ul>
            
          </div>
        </div>
        
          <div class="col-sm-4 hidden-xs">
            <img class="m-advanced-layout__featured-image " 
                src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/abfbb3e3-45fb-4ca8-9720-df3233a100c7.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&h=781&rect=0%2C0%2C1040%2C1638&w=450" alt=""
                 style="aspect-ratio: 450/781" loading="lazy">
          </div>
        
      </div>
    </div>
  </div>


  </section>





  <section class="m-section-striped" id="section-app-promo">
    

    <div>
      









<div class="m-promo-section ">
  
    <style>
      .m-promo-section__inner {
        background-image: url('https://restaumatic-production.imgix.net/uploads/media_library/d89746888da2d9510b64a9f031eaecd5.gif?auto=compress%2Cformat&crop=focalpoint&fit=crop&max-h=700&max-w=767') !important;
      }

      @media screen and (min-width: 768px) {
        .m-promo-section__inner {
          background-image: url('https://restaumatic-production.imgix.net/uploads/media_library/d89746888da2d9510b64a9f031eaecd5.gif?auto=compress%2Cformat&crop=focalpoint&fit=max&h=auto&w=1920') !important;
        }
      }
    </style>
  
  <div class="m-promo-section__inner m-section "  style="background-image: url('https://restaumatic-production.imgix.net/uploads/media_library/d89746888da2d9510b64a9f031eaecd5.gif?auto=compress%2Cformat&crop=focalpoint&fit=max&h=auto&w=1920');">
    

    <div class="m-promo-section__container">
      <div class="m-promo-section__item " >
        <div class="m-promo-section__item-inner">
          
      <header class="m-page-subheader">
        <h2 class="m-page-subheader__heading">
          <span class="m-page-subheader__sup-title">
            Aplikacja mobilna
          </span>
          <span class="m-page-subheader__title">
            Pobierz naszą aplikację
          </span>
        </h2>
      </header>
    

          <p class="m-promo-section__text">
            Pobierz appkę już teraz
          </p>

          <p class="m-promo-section__action-btn">
            
              <a href="https://play.google.com/store/apps/details?id=com.restaumatic.u_turka_kebab_production" class="m-promo-section__action" target="_blank" data-ga-action="Google Play promo section clicks">
                <img src="https://restaumatic-production.imgix.net/uploads/media_library/93051dee75af4ff526c7b51af9e13001.png?auto=compress%2Cformat&crop=focalpoint&fit=max&h=80&w=auto" class="img-responsive" alt="Pobierz z Google Play" loading="lazy">
              </a>
            
            
          </p>
        </div>
      </div>

      
        <p class="m-promo-section__item u-mb0  " >
          <img src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/cc377c26-b1de-4e26-9115-61caaa49dc7d.png?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&rect=0%2C0%2C420%2C400"  class="m-promo-section__image" alt="Pobierz naszą aplikację" loading="lazy">
        </p>
      
    </div>
  </div>
</div>

    </div>
  </section>







  
<section class="m-section m-section--top m-section-striped " id="section-contact">
  <header class="m-page-subheader m-page-subheader--center " >
    <h2 class="m-page-subheader__heading">
      
        <span class="m-page-subheader__sup-title">
          Masz pytania?
        </span>
      
      <span class="m-page-subheader__title">
        Skontaktuj się z nami
      </span>
    </h2>
    <p class="m-page-subheader__description">
      Napisz lub zadzwoń do nas!
    </p>
  </header>

  <div class="m-map m-map--one-page-section " >
    <iframe class="m-map__embed" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBZEvwcgAr3C0vAq75h5GN06LeuNx_bmmU&amp;q=U+Turka+kebab%2C+Tadeusza+Regera+3%2C+43-382+Bielsko-Bia%C5%82a" loading="lazy"></iframe>

  </div>
</section>




    



<footer class="m-footer">

  <div class="container">
    
      

  <div class="m-footer__content m-footer__content--main " data-restaurant-visible="u-turka-kebab">
  <div class="m-footer__cols " data-restaurant-visible="u-turka-kebab">
    <div class="m-footer__col m-footer__col--logo">
      <a href="/" aria-label="Przejdź do strony głównej">
        <img src="https://restaumatic-production.imgix.net/uploads/restaurants/352263/logo/1738059535.png?auto=compress%2Cformat&amp;crop=focalpoint&amp;fit=max&amp;h=200&amp;w=200" class="m-footer__logo-img" alt="U TURKA Kebab logo">
      </a>
    </div>
    <div class="m-footer__col">
      
        Tadeusza Regera 3, 43-382 Bielsko-Biała
      
      
        <br>
        Telefon:
        
          <a href="tel:739-410-071" class="u-link-unstyled" data-ga-action="phone_click">739 410 071</a>
        
      
      

      

  



      
    </div>
    
      <div class="m-footer__col">
        <p class="u-mb5">
          Obserwuj nas na:
        </p>
        


  
  
  
  
  <div class="m-icon-group" >
    <ul class="m-icon-group__list">
      
        <li class="m-icon-group__list-item">
          <a href="https://www.facebook.com/uturkakebab.gmail.eu/" title="Facebook" class="btn btn-primary m-icon-group__item" target="_blank" rel="noopener noreferrer">
            <span class="icon-facebook" aria-hidden="true"></span>
          </a>
        </li>
      
      
      
      
    </ul>
  </div>
  
      </div>
    

    <div class="m-footer__col">
      <p class="u-mb6 u-optional-content">Gotówka, karta lub szybki przelew</p>

      <p class="u-mb0">
        <a href="/restauracja/u-turka-kebab" class="btn btn-primary btn-block">
          Zamów online
        </a>
      </p>
    </div>
  </div>
</div>
      
        <div class="m-footer__content m-footer__content--tight u-hidden-app">
          

<div class="u-hidden-app">
  <p class="m-footer__app-badges">
    
      <a href="https://play.google.com/store/apps/details?id=com.restaumatic.u_turka_kebab_production" target="_blank" class="u-hover-opacity" data-ga-action="Google Play Badge clicks (footer)" data-ga-label="home">
        <img src="https://restaumatic-production.imgix.net/uploads/media_library/93051dee75af4ff526c7b51af9e13001.png?auto=compress%2Cformat&crop=focalpoint&fit=max&h=70&w=auto" class="" alt="Pobierz z Google Play" loading="lazy">
      </a>
    
    
  </p>
</div>

        </div>

<small class="m-footer-info ">
  <span class="m-footer-info__terms">
    <span class="u-text-nowrap">
  <a href="/terms" class="m-footer__link" rel="nofollow">
    Regulaminy
  </a> |
</span>
<span class="u-text-nowrap">
  <a href="/privacy-policy" class="m-footer__link" rel="nofollow">
    Polityka prywatności
  </a> |
</span>
<span class="u-hidden-app u-text-nowrap">
  <a href="#" role="button" data-cc="show-preferencesModal" data-field-id="showPreferences" class="m-footer__link" rel="nofollow">
    Ustawienia ciasteczek
  </a> |
</span>
<span class="u-text-nowrap">
  <a href="/zgody-marketingowe" class="m-footer__link" rel="nofollow">
    Zgody marketingowe
  </a> |
</span>
<span class="u-text-nowrap">
  <a href="/accessibility-statement" class="m-footer__link" rel="nofollow">
    Deklaracja dostępności
  </a> |
</span>
<span class="u-text-nowrap">
  <a href="/admin" class="m-footer__link" rel="nofollow">
    Panel Restauratora
  </a>
</span>

  </span>
  
    <span class="m-footer-info__info powered-by ">
            <div data-hypernova-key="PoweredBy" data-hypernova-id="eddd92c9-483f-44a0-b63a-c65a26045dd1"></div>
      <script type="application/json" data-hypernova-key="PoweredBy" data-hypernova-id="eddd92c9-483f-44a0-b63a-c65a26045dd1"><!--{"poweredByLinkClass":"m-footer__link u-text-decoration-none","__context__":{"locale":"pl","defaultLocale":"pl","country":"PL","currency":"PLN","siteId":330407,"accountId":317620}}--></script>


    </span>
  
</small>

  </div>
</footer>

  </div>

  <aside class="cookie-warning hide">
  <p class="cookie-warning__inner u-mb0">
    Strona korzysta z plików cookies w celu realizacji usług. Możesz określić warunki przechowywania lub dostępu do plików cookies w Twojej przeglądarce.
    <button type="button" class="btn btn-sm btn-light cookie-warning__btn">Rozumiem</button>
  </p>
</aside>
  
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Restaurant",
    "@id": "https://uturkakebab.com.pl/restauracja/u-turka-kebab",
    "name": "U TURKA Kebab",
    "description": "U TURKA Kebab - Zamów przez internet, zapłac gotówką lub online, dowieziemy do domu i biura",
    "telephone": "739 410 071",
    "url": "https://uturkakebab.com.pl/restauracja/u-turka-kebab",
    "menu": "https://uturkakebab.com.pl/restauracja/u-turka-kebab",
    "image": "https://restaumatic-production.imgix.net/uploads/restaurants/352263/logo/1738059535.png?auto=compress%2Cformat&crop=focalpoint&fit=clip&h=500&w=500",
    "logo": "https://restaumatic-production.imgix.net/uploads/restaurants/352263/logo/1738059535.png?auto=compress%2Cformat&crop=focalpoint&fit=clip&h=500&w=500",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Bielsko-Biała",
      "addressRegion": null,
      "postalCode": "43-382",
      "streetAddress": "Tadeusza Regera 3",
      "addressCountry": "PL"
    },
    "openingHours": ["Mo 14:00-20:00","Tu 14:00-20:00","We 14:00-20:00","Th 14:00-20:00","Fr 14:00-20:00","Sa 14:00-20:00","Su 14:00-20:00"],
    "servesCuisine": [
      "Kebab"
    ],
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": "49.8084455291692",
      "longitude": "18.9842667805806"
    },
    "potentialAction": {
      "@type": "OrderAction",
      "target": {
        "@type": "EntryPoint",
        "urlTemplate": "https://uturkakebab.com.pl/restauracja/u-turka-kebab",
        "contentType": "text/html",
        "inLanguage": "pl",
        "actionPlatform": [
          "http://schema.org/DesktopWebPlatform",
          "http://schema.org/MobileWebPlatform"
        ]
      },
      "deliveryMethod": [
        
      ],
      "priceSpecification": {
        "@type": "DeliveryChargeSpecification",
        "appliesToDeliveryMethod": "http://purl.org/goodrelations/v1#DeliveryModeOwnFleet",
        "priceCurrency": "PLN",
        "maxPrice": null,
        "minPrice": null,
        "eligibleTransactionVolume": {
          "@type": "PriceSpecification",
          "priceCurrency": "PLN",
          "maxPrice": null,
          "minPrice": null,
        }
      }
    },
    "review": [
      
        
        {
          "@type": "Review",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": 4
          },
          "author": {
            "@type": "Person",
            "name": "Mateusz"
          },
          "reviewBody": "Kebab bardzo dobry. Kupuje dosc czesto. Cena spoko. Nie jest to kraft ale lepszy niz u innych. Polecam",
          "datePublished": "2025-07-21 23:51:08 +0200"
        }
      
        ,
        {
          "@type": "Review",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": 5
          },
          "author": {
            "@type": "Person",
            "name": "Mateusz"
          },
          "reviewBody": "Wszystko smaczne i ciepłe. Polecam.",
          "datePublished": "2025-07-19 06:23:33 +0200"
        }
      
        ,
        {
          "@type": "Review",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": 5
          },
          "author": {
            "@type": "Person",
            "name": "Krzysztof"
          },
          "reviewBody": "Zamówienie online bezproblemowe, jedzenie dobre i ciepłe. ",
          "datePublished": "2025-07-04 21:48:19 +0200"
        }
      
        ,
        {
          "@type": "Review",
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": 5
          },
          "author": {
            "@type": "Person",
            "name": "Aga"
          },
          "reviewBody": "Smacznie, szybka dostawa",
          "datePublished": "2025-04-01 15:07:45 +0200"
        }
      
    ],
    "aggregateRating": {
      "@type": "AggregateRating",
      "worstRating": 1,
      "bestRating": 5,
      "ratingValue": 4.8,
      "ratingCount": 4
    }
  }
  </script>





  <div id="free-delivery-messages-container" aria-live="polite"></div>

  <div class="modal fade creator" id="creator" tabindex='-1' role='dialog'>
</div>

  <div class="js-dish-creator"> </div>


  <template id="allergens-popover" style="display: none;">
  <div class="js-content"></div>
  <div class="u-text-center">
    <button class="btn btn-link u-font-size-inherit" type="button" data-bs-target="#allergens-modal" data-bs-toggle="modal">Oznaczenia alergenów</button>
  </div>
</template>

<div class="modal fade" id="allergens-modal" tabindex="-1" role="dialog" aria-labelledby="allergens-modal__title">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button
          type="button"
          aria-label="Zamknij"
          data-bs-dismiss="modal"
          class="modal-close"
        >
          <span aria-hidden="true" class="icon-cancel"></span>
        </button>
        <h4 class="modal-title" id="allergens-modal__title">Oznaczenia alergenów</h4>
      </div>
      <div class="modal-body">
        <ol>
<li>Gluten</li>
<li>Skorupiaki</li>
<li>Jaja</li>
<li>Ryby</li>
<li>Orzeszki ziemne</li>
<li>Soja</li>
<li>Mleko</li>
<li>Orzechy</li>
<li>Seler</li>
<li>Gorczyca</li>
<li>Sezam</li>
<li>Dwutlenek siarki</li>
<li>Łubin</li>
<li>Mięczaki</li>
</ol>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-bs-dismiss="modal">Zamknij</button>
      </div>
    </div>
  </div>
</div>
    <aside id="sticky-cart-button" class="m-dock u-hidden-gfb-up">
  <div id="sticky-cart-button-alerts" aria-live="polite"></div>

  <div class="m-dock__content">
    <button type="button" class="btn btn-primary d-flex justify-content-center align-items-center u-full-width js-cart-button" data-ga-action="Open cart (Bar clicks)" data-field-id="Menu.openCartMobile">
      <span class="m-badge m-badge--primary-text m-badge--rounded u-mr2" data-cart="item_count" data-field-id="Menu.openCartMobile.quantity"></span>
      <span class="u-text-bold u-line-height-1">Koszyk</span>
      <span class="u-text-normal u-line-height-1 u-ml2" data-cart="item_price"></span>
    </button>
  </div>
</aside>

    <aside class="m-floating-action u-hidden-gfb-down js-fab">
  <button type="button" class="m-floating-action__btn m-floating-action__btn--text js-cart-button"
    data-ga-action="Open cart (FAB clicks)" data-field-id="Menu.openCartDesktop">
    <span class="m-floating-action__btn-text">Koszyk</span><span class="icon-shopping-cart" aria-hidden="true"></span>
    <span class="m-floating-action__badge" data-cart="item_count" data-field-id="Menu.openCartDesktop.quantity"></span>
  </button>
</aside>
<script id="address_not_found_msg" type="text/html">
<div>
  <h4>Niepoprawny adres!</h4>
  <br/>
  <p><i class='icon-alert-sign'></i> Sprawdź czy miasto i ulica się zgadza!</p>
</div>
</script>

<div class="modal fade" id="error" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button
          type="button"
          aria-label="Zamknij"
          data-bs-dismiss="modal"
          class="modal-close"
        >
          <span aria-hidden="true" class="icon-cancel"></span>
        </button>
        <h3 id="error_title"></h3>
      </div>
      <div class="modal-body">
        <div class="error">
          <div id="error_msg" class="text-centered"></div>
        </div>
      </div>
      <div class="modal-footer">
        <a href="#" data-bs-dismiss="modal" class="btn btn-primary">Ok</a>
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="notification_modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button
          type="button"
          aria-label="Zamknij"
          data-bs-dismiss="modal"
          class="modal-close"
        >
          <span aria-hidden="true" class="icon-cancel"></span>
        </button>
        <h3 class="modal-title">NOWOŚĆ!</h3>
      </div>

      <div class="modal-body">
        <p style="text-align:center;"><strong>Mamy najlepszy w Polsce system zamawiania jedzenia online.</strong></p>
<p style="text-align:center;">Gotówka, karta lub szybki przelew<br>Bez logowania i rejestracji<br>20 sekund i załatwione!</p>
      </div>

      <div class="modal-footer text-centered">
        
        
        
        <a href="#"  data-bs-dismiss="modal" class="btn btn-primary btn-lg">OK!</a>
      </div>
    </div>
  </div>
</div>



  <script>
    Skubacz.configuration.smartAppBanner = {
      daysHidden: 180,
      daysReminder: 365,
      title: "U TURKA Kebab",
      author: "Aplikacja mobilna",
      button: "Zobacz",
      store: {
        ios: "W App Store",
        android: "W Google Play",
        windows: "W Windows store"
      },
      price: {
        ios: "ZA DARMO",
        android: "ZA DARMO",
        windows: "ZA DARMO"
      },
      appStoreLanguage: "pl"
    }
  </script>
<script type="text/javascript">
  Skubacz.configuration.view_name = 'home';
  Skubacz.configuration.enable_cart_sizing = false;
  Skubacz.configuration.country = "PL";
  Skubacz.configuration.currency = "PLN";
  Skubacz.configuration.currency_format = {"delimiter":"","format":"%n %u","precision":2,"separator":",","significant":false,"strip_insignificant_zeros":false,"unit":"zł"};
  Skubacz.configuration.time_zone = "Europe/Warsaw";
  Skubacz.configuration.authenticity_token = '__CROSS_SITE_REQUEST_FORGERY_PROTECTION_TOKEN__';
  Skubacz.configuration.theme_name = "fiesta";
  Skubacz.configuration.theme_settings = {"cart_dish_images":"0","cart_modal_image":""};
  Skubacz.configuration.environment = "production";
  Skubacz.configuration.imgix_url = "https://restaumatic-production.imgix.net";
  Skubacz.configuration.restaurant_slug = "u-turka-kebab";
  // Remove after finishing OpenCage tests
  Skubacz.configuration.id = "352263";
  Skubacz.configuration.site_id = 330407;
  Skubacz.configuration.site_slug = "u-turka-kebab";
  Skubacz.configuration.account_id = 317620;
  Skubacz.configuration.feature_flags = {"sticky_nav":false};
  Skubacz.configuration.menu = { skip_group_scroll: false }; 
  Skubacz.configuration.prefetch_menu_on_homepage =
    ("home" === "home" &&
     false &&
     1 === 1)
      ? "/restauracja/u-turka-kebab"
      : null;
  Skubacz.configuration.customer_survey_url = "https://docs.google.com/forms/d/e/1FAIpQLSfqmYbMLaxDkw5X1P6_o6nafzervNLIRFq0Zkxs7QKMtSFVsw/formResponse";
  Skubacz.configuration.has_mobile_app = true;
  Skubacz.configuration.mobile_app = {"google_play_url":"https://play.google.com/store/apps/details?id=com.restaumatic.u_turka_kebab_production","itunes_url":null,"badges":{"google_play":"/uploads/media_library/93051dee75af4ff526c7b51af9e13001.png","app_store":"/uploads/media_library/e20d9205073c3afcec47f9946e324cb6.png"}};

  // Tracking
  Skubacz.configuration.tracking = {"ahoyEnabled":true,"analyticsV4":{"restaumatic":"G-2XDL375QMZ","site":"G-WT7TRYR5K1"},"facebookPixelId":"","adwordsAnalyticsV4":null,"themeName":"fiesta","siteName":"U TURKA Kebab","siteId":330407,"country":"PL","viewName":"home","activeMenu":false};
</script>


        <meta data-cart-menu-path="/api/v1/sites/restaurant_menu/352263/pl?v=a31dd95f825c7ebd71d67dd6c6f4994b"
          data-cart-restaurant-path="/restauracja/u-turka-kebab"
          data-cart-restaurant-id="352263"
        >
      
<script type="text/javascript">
(function () {
  function isNotSupportedBrowser() {
    var msie = window.navigator.userAgent.indexOf("MSIE"); // IE 10 or below
    var trident = window.navigator.userAgent.indexOf("Trident/"); // IE 11
    return msie > 0 || trident > 0;
  }

  if (isNotSupportedBrowser()) {
    document.getElementById("notification-old-browser").style.display = "block";
  }
})();
</script>


<script type="text/javascript">
  // Tracking function with a queue property, supports one subscriber
  Skubacz.tracking = (function () {
    var q = [], l = null
    var f = function (event) {
      if (l) {
        l(event)
      } else {
        q.push(event)
      }
    }
    f.q = q
    // subscribe and consume the queue
    f.subscribe = function (listener) {
      l = listener
    }
    // Backwards compatibility in AM (can be removed after theme upgrade)
    f.startTracking = function(clientId) {
      f({ tag: 'InitActiveMenu', clientId: clientId});
    }
    return f
  })()
</script>


<script src="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/runtime-095159e38cecd3baf277.js"></script>
<script src="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/app-b46b20b68982b4d7c4be.js"></script>
<script src="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/site-translations-pl-dd63332d3de46046e1d1.js"></script>

<script type="text/javascript">
  I18n.defaultLocale = "pl";
  I18n.locale = "pl";
</script>

<script src="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/client-d48c161dea92b3f10a91.js"></script>




  <script type="text/plain" data-category="analytics" src="https://www.googletagmanager.com/gtag/js?id=G-2XDL375QMZ" defer></script>





<script type="text/javascript">
  var widgetAppId = '425338764160270.0';
  var version = "v3.0";
  var likeBox = false;


  var finalAppId = likeBox ? widgetAppId : ''
  if (finalAppId != '') {
    window.fbAsyncInit = function() {
      FB.init({
        appId      : finalAppId,
        cookie     : true,
        xfbml      : true,
        version    : version
      });
    };

    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://connect.facebook.net/en_US/sdk.js";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
  }
</script>



</body>
</html>
