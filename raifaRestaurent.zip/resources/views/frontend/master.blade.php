any<!DOCTYPE html>
<html lang="pl" class="no-js">
<head>
  <!-- ===== Meta Information ===== -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>U TURKA Kebab - Zamów i zapłać online - U TURKA Kebab</title>
  <meta name="description" content="U TURKA Kebab - Zamów przez internet, zapłac gotówką lub online, dowieziemy do domu i biura"/>
  <meta name="keywords" content="Zamów online, Dostawa, Dowóz, Płatności online"/>
  <meta name="google-site-verification" content="dAw_0ytzl53_wNzVHeoO7UZClRN4ONqJRoxTFCTdwTo"/>

  <!-- ===== App Metadata ===== -->
  <meta name="google-play-app" content="app-id=com.restaumatic.u_turka_kebab_production">
  <link rel="canonical" href="https://www.uturkakebab.com.pl/"/>

  <!-- ===== Open Graph ===== -->
  <meta property="og:title" content="U TURKA Kebab - Zamów i zapłać online - U TURKA Kebab">
  <meta property="og:description" content="U TURKA Kebab - Zamów przez internet, zapłac gotówką lub online, dowieziemy do domu i biura">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.uturkakebab.com.pl/"/>

  <!-- ===== Favicons ===== -->
  <link rel="shortcut icon" href="https://restaumatic-production.imgix.net/uploads/sites/330407/1738061759.png?auto=compress&format&h=32&w=32" sizes="32x32">
  <link rel="icon" href="https://restaumatic-production.imgix.net/uploads/sites/330407/1738061759.png?auto=compress&format&h=192&w=192" sizes="192x192">
  <link rel="apple-touch-icon-precomposed" href="https://restaumatic-production.imgix.net/uploads/sites/330407/1738061759.png?auto=compress&format&h=180&w=180">
  <meta name="msapplication-TileImage" content="https://restaumatic-production.imgix.net/uploads/sites/330407/1738061759.png?auto=compress&format&h=270&w=270">

  <!-- ===== Fonts ===== -->
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link rel="dns-prefetch" href="//fonts.googleapis.com">
  <link rel="preconnect" href="//fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Merriweather:300,400|Berkshire+Swash:400&subset=latin-ext&display=swap" rel="stylesheet">

  <!-- ===== Stylesheets ===== -->
  <link rel="stylesheet" href="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/fiesta-14a5ed3b9c6d1af28fc2.css" media="screen">
  <link rel="stylesheet" href="https://dmbdno5jmf70v.cloudfront.net/uploads/sites/330407/themes/370047/assets/theme-b525643f20d97723171e21be9b9e28b9.css" media="screen">

  <!-- ===== Preload Assets ===== -->
  <link rel="preload" as="font" href="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/font/font-awesome-min-ec97639751ebebe81c1d.woff2" type="font/woff2" crossorigin="anonymous">

  <!-- ===== Analytics & Error Tracking ===== -->
  <script src="https://js.sentry-cdn.com/844eecb5a0da4da99b3918516f5a379d.min.js" crossorigin="anonymous"></script>

  <!-- ===== App Configuration ===== -->
  <script>
    if (!window.Skubacz) {
      window.Skubacz = { configuration: { locale: "pl" } };
    }
    Skubacz.configuration.editing = false;
    Skubacz.configuration.breakpoints = {
      gridFloatBreakpoint: 992,
      smallMin: 640,
      mediumMin: 992,
      extraMediumMin: 1024,
      largeMin: 1400,
      extraLargeMin: 1750
    };
    document.documentElement.className = document.documentElement.className.replace(/\bno-js\b/, 'js');
  </script>

  <!-- ===== Fiesta Script ===== -->
  <script src="https://d2sv10hdj8sfwn.cloudfront.net/production/pendolino/webpack/fiesta-14a5ed3b9c6d1af28fc2.js"></script>
</head>

<body class="l-home" data-bs-no-jquery="true">
  <script>
    if ("RestaumaticMobileApp" in window &&
        typeof window.RestaumaticMobileApp.isMobileApp === "function" &&
        window.RestaumaticMobileApp.isMobileApp()) {
      document.body.classList.add("l-mobile-app");
    }
  </script>

@include('frontend.partials.menu-bar')

  <!-- ===== Header Section ===== -->
  <section class="m-header__wrapper">
    <!-- Background Image -->
    <div class="m-header__cover-wrapper">
      <div class="m-header__bg-single-img js-animate__init-element">
        <img
          class="m-header__cover"
          srcset="
            https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/42cd5e28-8d5f-416b-b0cb-c440c12ee46c.jpg?w=1920 1920w,
            https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/42cd5e28-8d5f-416b-b0cb-c440c12ee46c.jpg?w=1280 1280w,
            https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/42cd5e28-8d5f-416b-b0cb-c440c12ee46c.jpg?w=768 768w
          "
          sizes="100vw"
          src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/42cd5e28-8d5f-416b-b0cb-c440c12ee46c.jpg?w=1920"
          alt="Restaurant background"
        />
      </div>
    </div>

    <!-- Content -->
    <div class="m-header__content">
      <!-- Social Icons -->
      <div class="m-header__social-icons m-header__social-icons--left">
        <div class="m-icon-group m-icon-group--vertical">
          <ul class="m-icon-group__list">
            <li class="m-icon-group__list-item">
              <a
                href="https://www.facebook.com/uturkakebab.gmail.eu/"
                title="Facebook"
                class="btn btn-primary m-icon-group__item"
                target="_blank"
                rel="noopener noreferrer"
              >
                <span class="icon-facebook" aria-hidden="true"></span>
              </a>
            </li>
          </ul>
        </div>
      </div>

      <!-- Hero Section -->
      <div class="m-header__hero">
        <div class="m-hero m-hero--media js-slider splide"
             data-slider='{"type": "fade", "autoplay": false, "interval": 5000}'>
          <div class="splide__track">
            <div class="m-hero__list splide__list" id="header-slider">
              <article class="m-hero__content splide__slide js-slider__animation-fix">
                <div class="m-header__container">
                  <div class="m-hero__row u-mb0">
                    <div class="m-hero__col m-hero__col--center">
                      <div class="m-hero__col-inner">
                        <!-- Hero Title -->
                        <h1 class="m-hero__header">
                          <span class="m-hero__sup-title fadeInDown">Turecki smak</span>
                          <span class="m-hero__title fadeInDown">w każdym kęsie!</span>
                        </h1>

                        <!-- CTA -->
                        <p class="m-hero__action fadeInDown">
                          <a href="menu.php" class="btn btn-primary-on-dark btn-gfb-lg">
                            Zamów online
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<div id="main-content" class="m-main  m-main--nav-bottom">
  <section id="section-about-us">
    <div class="m-info-boxes">
      <ul class="m-info-boxes__list">

        <!-- Location -->
        <li class="m-info-boxes__item">
          <div class="m-info-boxes__icon">
            <div class="m-icon-item">
              <span class="icon-location" aria-hidden="true"></span>
            </div>
          </div>
          <div class="m-info-boxes__content">
            <h2 class="m-heading m-info-boxes__title">Gdzie jesteśmy?</h2>
            <p class="m-info-boxes__description">
              U TURKA Kebab<br>
              Tadeusza Regera 3<br>
              43-382 Bielsko-Biała
            </p>
          </div>
        </li>

        <!-- Phone -->
        <li class="m-info-boxes__item">
          <div class="m-info-boxes__icon">
            <div class="m-icon-item">
              <span class="icon-phone" aria-hidden="true"></span>
            </div>
          </div>
          <div class="m-info-boxes__content">
            <h2 class="m-heading m-info-boxes__title">Zadzwoń do nas</h2>
            <p class="m-info-boxes__description">
              <a href="tel:739-410-071" class="u-link-unstyled" data-ga-action="phone_click">
                739 410 071
              </a>
            </p>
          </div>
        </li>

        <!-- Opening Hours -->
        <li class="m-info-boxes__item">
          <div class="m-info-boxes__icon">
            <div class="m-icon-item">
              <span class="icon-time" aria-hidden="true"></span>
            </div>
          </div>
          <div class="m-info-boxes__content">
            <h2 class="m-heading m-info-boxes__title">Godziny otwarcia</h2>
            <div class="m-info-boxes__description">
              <div class="m-restaurant-hours js-restaurant-hours js-restaurant-hours-opening"
                  data-restaurant-slug="u-turka-kebab"
                  data-active-classes=""
                  data-inactive-classes="">

                <!-- Today's Hours -->
                <div class="m-restaurant-hours__item m-restaurant-hours__item--singular js-restaurant-hours-present-day">
                  <span class="m-restaurant-hours__header js-restaurant-hours-header">Dzisiaj:&nbsp;</span>
                  <span class="m-restaurant-hours__data-wrapper">
                    <span class="m-restaurant-hours__data js-restaurant-hours-data"></span>
                    <button type="button" 
                            class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" 
                            data-trigger="focus" 
                            data-container="body" 
                            data-target="#opening-hours-popover-u-turka-kebab" 
                            aria-label="teraz">
                      <i class="icon-info-sign"></i>
                    </button>
                    <button type="button" 
                            class="m-restaurant-hours__btn-collapse js-restaurant-hours-btn-collapse collapsed" 
                            data-bs-toggle="collapse" 
                            data-bs-target="#opening-hours-collapse-u-turka-kebab" 
                            aria-label="Godziny otwarcia" 
                            aria-expanded="false">
                      <span class="icon-caret-up collapsed__hide"></span>
                      <span class="icon-caret-down collapsed__show"></span>
                    </button>
                  </span>
                  <span class="clearfix"></span>
                </div>

                <!-- All Days -->
                <div class="js-restaurant-hours-all-days collapse" id="opening-hours-collapse-u-turka-kebab">
                  <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="1">
                    <span class="m-restaurant-hours__header js-restaurant-hours-header">poniedziałek</span>
                    <span class="m-restaurant-hours__data-wrapper">
                      <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
                      <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover" 
                              data-trigger="focus" data-container="body" data-target="#opening-hours-popover-u-turka-kebab" 
                              aria-label="teraz">
                        <i class="icon-info-sign"></i>
                      </button>
                    </span>
                    <span class="clearfix"></span>
                  </div>

                  <!-- Repeat similar blocks for Tuesday to Sunday -->
                  <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="2">
                    <span class="m-restaurant-hours__header js-restaurant-hours-header">wtorek</span>
                    <span class="m-restaurant-hours__data-wrapper">
                      <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
                      <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover">
                        <i class="icon-info-sign"></i>
                      </button>
                    </span>
                    <span class="clearfix"></span>
                  </div>

                  <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="3">
                    <span class="m-restaurant-hours__header js-restaurant-hours-header">środa</span>
                    <span class="m-restaurant-hours__data-wrapper">
                      <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
                      <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover">
                        <i class="icon-info-sign"></i>
                      </button>
                    </span>
                    <span class="clearfix"></span>
                  </div>

                  <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="4">
                    <span class="m-restaurant-hours__header js-restaurant-hours-header">czwartek</span>
                    <span class="m-restaurant-hours__data-wrapper">
                      <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
                      <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover">
                        <i class="icon-info-sign"></i>
                      </button>
                    </span>
                    <span class="clearfix"></span>
                  </div>

                  <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="5">
                    <span class="m-restaurant-hours__header js-restaurant-hours-header">piątek</span>
                    <span class="m-restaurant-hours__data-wrapper">
                      <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
                      <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover">
                        <i class="icon-info-sign"></i>
                      </button>
                    </span>
                    <span class="clearfix"></span>
                  </div>

                  <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="6">
                    <span class="m-restaurant-hours__header js-restaurant-hours-header">sobota</span>
                    <span class="m-restaurant-hours__data-wrapper">
                      <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
                      <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover">
                        <i class="icon-info-sign"></i>
                      </button>
                    </span>
                    <span class="clearfix"></span>
                  </div>

                  <div class="m-restaurant-hours__item js-restaurant-hours-day" data-day="7">
                    <span class="m-restaurant-hours__header js-restaurant-hours-header">niedziela</span>
                    <span class="m-restaurant-hours__data-wrapper">
                      <span class="m-restaurant-hours__data js-restaurant-hours-data">14:00 - 20:00</span>
                      <button type="button" class="m-restaurant-hours__btn-popover js-restaurant-hours-btn-popover js-popover">
                        <i class="icon-info-sign"></i>
                      </button>
                    </span>
                    <span class="clearfix"></span>
                  </div>

                </div> <!-- /All Days -->

                <!-- Popover -->
                <div class="js-restaurant-hours-popover" style="display: none;" id="opening-hours-popover-u-turka-kebab">
                  <div class="pull-left js-restaurant-hours-popover-title"></div>
                  <div class="pull-right m-popover__dismiss">
                    <button type="button" class="close js-dismiss-popover" aria-hidden="true">×</button>
                  </div>
                  <div class="clearfix"></div>
                  <div class="js-restaurant-hours-popover-details"></div>
                  <div class="js-restaurant-hours-popover-info"></div>
                </div>

              </div>
            </div>
          </div>
        </li>

      </ul>
    </div>
  </section>

<section class="m-section m-section--inner-padding-alt m-section-striped" id="section-info-box">
  <div class="container">
    <div class="m-info-box">

      <!-- Images Column -->
      <div class="m-info-box__col m-info-box__col--media-last">

        <picture class="u-block u-flex-grow">
          <img class="m-info-box__image" 
               src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/5ef4b1c4-679c-4687-8354-26f97cca56e9.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=586&max-w=390&rect=0%2C0%2C718%2C1125"  
               alt="" 
               loading="lazy" 
               style="aspect-ratio: 390/586;">
        </picture>

        <picture class="u-block u-flex-grow">
          <img class="m-info-box__image m-info-box__image--featured" 
               src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/5ef4b1c4-679c-4687-8354-26f97cca56e9.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=547&max-w=420&rect=1108%2C112%2C619%2C1012"  
               alt="" 
               loading="lazy" 
               style="aspect-ratio: 420/547;">
        </picture>

      </div>

      <!-- Content Column -->
      <div class="m-info-box__col">
        <div class="m-info-box__content">

          <!-- Header -->
          <div class="m-info-box__header">
            <header class="m-page-subheader">
              <h2 class="m-page-subheader__heading">
                <span class="m-page-subheader__sup-title">U TURKA Kebab</span>
                <span class="m-page-subheader__title">Bielsko-Biała</span>
              </h2>
            </header>
          </div>

          <!-- Description -->
          <div class="m-content-box m-info-box__description">
            Jeśli marzysz o soczystym kebabie, który przeniesie Cię w świat orientalnych smaków, zapraszamy U TURKA! 
            Tu znajdziesz wszystko, co najlepsze – od perfekcyjnie przyprawionego mięsa po świeże dodatki i aromatyczne sosy.
            <br><br>🌟 Przyjdź raz, a wrócisz po więcej! U TURKA Kebab to miejsce, gdzie smaki Orientu łączą się z domowym ciepłem.
          </div>

          <!-- Action Button -->
          <p class="m-info-box__action">
            <a href="menu.php" class="btn btn-primary btn-lg">Menu</a>
          </p>

        </div>
      </div>

    </div>
  </div>
</section>


<section class="m-section m-section--inner-padding m-section-striped" id="section-promotions">
  <div class="m-promo-boxes splide js-slider" data-slider='{"autoplay": false}' data-responsive='{"xsmall": 1, "medium": 2}'>

    <!-- Section Header -->
    <header class="m-page-subheader m-page-subheader--center">
      <h2 class="m-page-subheader__heading">
        <span class="m-page-subheader__sup-title">Sprawdź nasze</span>
        <span class="m-page-subheader__title">Najlepsze Promocje</span>
      </h2>
      <p class="m-page-subheader__description">
        <a href="/promocje" class="btn btn-link">Zobacz wszystkie promocje</a>
      </p>
    </header>

    <!-- Promo Slider Track -->
    <div class="splide__track">
      <div class="m-promo-boxes__list splide__list">

        <!-- Promo Item 1 -->
        <article class="m-promo-boxes__list-item splide__slide">
          <a href="menu.php" class="m-promo-boxes__item u-link-wrapper">
            <picture class="m-promo-boxes__media">
              <source srcset="https://restaumatic-production.imgix.net/uploads/media_library/71c4b2d9864b58138785e07cb532d7a2.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=625&max-w=375&rect=0%2C0%2C1960%2C1400" media="(max-width: 1200px)">
              <img class="m-promo-boxes__media-img" 
                   src="https://restaumatic-production.imgix.net/uploads/media_library/71c4b2d9864b58138785e07cb532d7a2.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=625&max-w=800&rect=0%2C0%2C1960%2C1400" 
                   alt="" loading="lazy">
            </picture>
            <div class="m-promo-boxes__body">
              <div class="m-promo-boxes__body-inner">
                <h3 class="m-heading m-promo-boxes__title">Rabat na pierwsze zamówienie !</h3>
                <p class="m-promo-boxes__description">Zamów i zgarnij rabat - 10 %</p>
                <p class="m-promo-boxes__action">
                  <span type="button" class="btn btn-default" tabindex="-1">Zobacz menu</span>
                </p>
              </div>
            </div>
          </a>
        </article>

        <!-- Promo Item 2 -->
        <article class="m-promo-boxes__list-item splide__slide">
          <a href="menu.php" class="m-promo-boxes__item u-link-wrapper">
            <picture class="m-promo-boxes__media">
              <source srcset="https://restaumatic-production.imgix.net/uploads/media_library/a52f3657cc53670a8a6579c9607bb677.png?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=625&max-w=375&rect=0%2C0%2C1920%2C1920" media="(max-width: 1200px)">
              <img class="m-promo-boxes__media-img" 
                   src="https://restaumatic-production.imgix.net/uploads/media_library/a52f3657cc53670a8a6579c9607bb677.png?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&max-h=625&max-w=800&rect=0%2C0%2C1920%2C1920" 
                   alt="" loading="lazy">
            </picture>
            <div class="m-promo-boxes__body">
              <div class="m-promo-boxes__body-inner">
                <h3 class="m-heading m-promo-boxes__title">6 zamówienie - 15 % RABATU!</h3>
                <p class="m-promo-boxes__description">Zgarnij - 15 % RABATU na 6 zamówienie ze strony!</p>
                <p class="m-promo-boxes__action">
                  <span type="button" class="btn btn-default" tabindex="-1">Zobacz menu</span>
                </p>
              </div>
            </div>
          </a>
        </article>

      </div>
    </div>

    <!-- Slider Indicators -->
    <div class="m-promo-boxes__indicators">
      <div class="m-indicators m-indicators--center">
        <ul class="m-indicators__dots splide__pagination js-slider__indicators"></ul>
      </div>
    </div>

  </div>
</section>


<section class="m-section m-section--inner-padding m-section-striped" id="section-reviews">

  <div class="m-testimonials">
    <div class="container">

      <!-- Section Header -->
      <header class="m-page-subheader m-page-subheader--center">
        <h2 class="m-page-subheader__heading">
          <span class="m-page-subheader__sup-title">Sprawdź co mówią o nas</span>
          <span class="m-page-subheader__title">Zadowoleni klienci</span>
        </h2>
        <p class="m-page-subheader__description">
          99,2% klientów jest z nas zadowolonych!
        </p>
        <p class="m-page-subheader__description">
          <a href="/opinie" class="btn btn-link">Zobacz wszystkie opinie</a>
        </p>
      </header>

      <!-- Testimonials Slider -->
      <div class="m-section m-section--bottom splide js-slider"
           data-slider='{"autoplay": false}'
           data-responsive='{"xsmall": 1, "small": 3}'>

        <div class="splide__track">
          <div class="m-testimonials__list splide__list">

            <!-- Testimonial Item 1 -->
            <article class="m-testimonials__item splide__slide">
              <p class="m-testimonials__content">
                Kebab bardzo dobry. Kupuje dosc czesto. Cena spoko. Nie jest to kraft ale lepszy niz u innych. Polecam
              </p>
              <footer class="m-testimonials__footer">
                <p class="m-heading m-testimonials__author">Mateusz</p>
              </footer>
            </article>

            <!-- Testimonial Item 2 -->
            <article class="m-testimonials__item splide__slide">
              <p class="m-testimonials__content">
                Wszystko smaczne i ciepłe. Polecam.
              </p>
              <footer class="m-testimonials__footer">
                <p class="m-heading m-testimonials__author">Mateusz</p>
              </footer>
            </article>

            <!-- Testimonial Item 3 -->
            <article class="m-testimonials__item splide__slide">
              <p class="m-testimonials__content">
                Zamówienie online bezproblemowe, jedzenie dobre i ciepłe.
              </p>
              <footer class="m-testimonials__footer">
                <p class="m-heading m-testimonials__author">Krzysztof</p>
              </footer>
            </article>

            <!-- Testimonial Item 4 -->
            <article class="m-testimonials__item splide__slide">
              <p class="m-testimonials__content">
                Smacznie, szybka dostawa
              </p>
              <footer class="m-testimonials__footer">
                <p class="m-heading m-testimonials__author">Aga</p>
              </footer>
            </article>

          </div>
        </div>

        <!-- Slider Indicators -->
        <div class="m-testimonials__indicators">
          <div class="m-indicators m-indicators--center">
            <ul class="m-indicators__dots splide__pagination js-slider__indicators"></ul>
          </div>
        </div>

      </div>
    </div>
  </div>

</section>



<section class="m-section m-section--inner-padding m-section-striped" id="section-gallery">
  <div id="gallery-advanced" class="m-advanced-layout">
    <div class="container">
      <div class="row">
        
        <!-- Left Column -->
        <div class="col-sm-8 m-advanced-layout__col-primary">
          <div class="m-advanced-layout__content-wrapper">
            
            <!-- Section Header -->
            <header class="m-page-subheader">
              <h2 class="m-page-subheader__heading">
                <span class="m-page-subheader__sup-title">Zobacz nasze</span>
                <span class="m-page-subheader__title">Potrawy i restauracje</span>
              </h2>
            </header>

            <!-- Description -->
            <div class="m-advanced-layout__content m-advanced-layout__content--cols">
              Zapraszamy do miejsca, gdzie kebab to prawdziwa uczta! U TURKA serwujemy jedynie to, co najlepsze – 
              wyborne mięso, świeże dodatki i autentyczne sosy, które podkreślają smak każdej potrawy.
            </div>

            <!-- Gallery List -->
            <ul class="m-advanced-layout__media-list">

              <!-- Gallery Item 1 -->
              <li class="m-advanced-layout__media-list-item">
                <a href="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/43c44e79-84b7-4fa5-9372-d44bb0a777c8.jpg?auto=compress%2Cformat&balph=28&blend=ffcc00&blur=0&bm=overlay&crop=focalpoint&fit=max&fp-x=0.5&fp-y=0.5&h=auto&rect=0%2C0%2C2000%2C1333&w=1920" 
                   class="m-overlay u-link-wrapper m-advanced-layout__item" 
                   data-lightbox="home-gallery-u-turka-kebab">
                  <picture class="m-overlay__item">
                    <img class="m-advanced-layout__item-image"
                         src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/43c44e79-84b7-4fa5-9372-d44bb0a777c8.jpg?auto=compress%2Cformat&balph=28&blend=ffcc00&blur=0&bm=overlay&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&h=295&rect=0%2C0%2C2000%2C1333&w=325" 
                         alt="Gallery Item 1" 
                         style="aspect-ratio: 325/295;" 
                         loading="lazy">
                  </picture>
                  <p class="m-overlay__content">
                    <span class="icon-search m-overlay__icon" aria-hidden="true"></span>
                  </p>
                </a>
              </li>

              <!-- Gallery Item 2 -->
              <li class="m-advanced-layout__media-list-item">
                <a href="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/25a16b76-da52-4416-a82b-20842970a1e0.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=max&fp-x=0.5&fp-y=0.5&h=auto&rect=0%2C0%2C1941%2C2000&w=1920" 
                   class="m-overlay u-link-wrapper m-advanced-layout__item" 
                   data-lightbox="home-gallery-u-turka-kebab">
                  <picture class="m-overlay__item">
                    <img class="m-advanced-layout__item-image"
                         src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/25a16b76-da52-4416-a82b-20842970a1e0.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&h=295&rect=0%2C0%2C1941%2C2000&w=325" 
                         alt="Gallery Item 2" 
                         style="aspect-ratio: 325/295;" 
                         loading="lazy">
                  </picture>
                  <p class="m-overlay__content">
                    <span class="icon-search m-overlay__icon" aria-hidden="true"></span>
                  </p>
                </a>
              </li>

              <!-- Gallery Item 3 -->
              <li class="m-advanced-layout__media-list-item">
                <a href="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/68845f2f-677a-4d8a-8780-8c87c8c33fde.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=max&fp-x=0.5&fp-y=0.5&h=auto&rect=621%2C472%2C744%2C816&w=1920" 
                   class="m-overlay u-link-wrapper m-advanced-layout__item" 
                   data-lightbox="home-gallery-u-turka-kebab">
                  <picture class="m-overlay__item">
                    <img class="m-advanced-layout__item-image"
                         src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/68845f2f-677a-4d8a-8780-8c87c8c33fde.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&h=295&rect=621%2C472%2C744%2C816&w=325" 
                         alt="Gallery Item 3" 
                         style="aspect-ratio: 325/295;" 
                         loading="lazy">
                  </picture>
                  <p class="m-overlay__content">
                    <span class="icon-search m-overlay__icon" aria-hidden="true"></span>
                  </p>
                </a>
              </li>

            </ul>
          </div>
        </div>

        <!-- Right Column -->
        <div class="col-sm-4 hidden-xs">
          <img class="m-advanced-layout__featured-image"
               src="https://restaumatic-production.imgix.net/uploads/accounts/317620/media_library/abfbb3e3-45fb-4ca8-9720-df3233a100c7.jpg?auto=compress%2Cformat&blur=0&crop=focalpoint&fit=crop&fp-x=0.5&fp-y=0.5&h=781&rect=0%2C0%2C1040%2C1638&w=450" 
               alt="Featured Image" 
               style="aspect-ratio: 450/781" 
               loading="lazy">
        </div>

      </div>
    </div>
  </div>
</section>



<section class="m-section m-section--top m-section-striped" id="section-contact">
  
  <!-- Section Header -->
  <header class="m-page-subheader m-page-subheader--center">
    <h2 class="m-page-subheader__heading">
      <span class="m-page-subheader__sup-title">
        Masz pytania?
      </span>
      <span class="m-page-subheader__title">
        Skontaktuj się z nami
      </span>
    </h2>
    <p class="m-page-subheader__description">
      Napisz lub zadzwoń do nas!
    </p>
  </header>

  <!-- Google Map -->
  <div class="m-map m-map--one-page-section">
    <iframe 
      class="m-map__embed"
      src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBZEvwcgAr3C0vAq75h5GN06LeuNx_bmmU&q=U+Turka+kebab%2C+Tadeusza+Regera+3%2C+43-382+Bielsko-Bia%C5%82a"
      loading="lazy"
      allowfullscreen
      referrerpolicy="no-referrer-when-downgrade">
    </iframe>
  </div>

</section>

</div>

  <!-- ===== Footer Section ===== -->
  <footer class="m-footer">
    <div class="container">
      <div class="m-footer__content m-footer__content--main">
        <div class="m-footer__cols">
          <!-- Logo -->
          <div class="m-footer__col m-footer__col--logo">
            <a href="/" aria-label="Przejdź do strony głównej">
              <img src="https://restaumatic-production.imgix.net/uploads/restaurants/352263/logo/1738059535.png?w=200&h=200"
                   class="m-footer__logo-img" alt="U TURKA Kebab logo">
            </a>
          </div>

          <!-- Address & Contact -->
          <div class="m-footer__col">
            <p>Tadeusza Regera 3, 43-382 Bielsko-Biała</p>
            <p>Telefon: <a href="tel:739-410-071" class="u-link-unstyled">739 410 071</a></p>
          </div>

          <!-- Social Media -->
          <div class="m-footer__col">
            <p class="u-mb5">Obserwuj nas na:</p>
            <div class="m-icon-group">
              <ul class="m-icon-group__list">
                <li class="m-icon-group__list-item">
                  <a href="https://www.facebook.com/uturkakebab.gmail.eu/"
                     title="Facebook"
                     class="btn btn-primary m-icon-group__item"
                     target="_blank"
                     rel="noopener noreferrer">
                    <span class="icon-facebook" aria-hidden="true"></span>
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <!-- Payment & CTA -->
          <div class="m-footer__col">
            <p class="u-mb6">Gotówka, karta lub szybki przelew</p>
            <a href="/restauracja/u-turka-kebab" class="btn btn-primary btn-block">
              Zamów online
            </a>
          </div>
        </div>
      </div>

      <!-- Footer Bottom Links -->
      <div class="m-footer__content m-footer__content--tight u-hidden-app">
        <div class="u-hidden-app">
          <p class="m-footer__app-badges">
            <a href="https://play.google.com/store/apps/details?id=com.restaumatic.u_turka_kebab_production"
               target="_blank" class="u-hover-opacity">
              <img src="https://restaumatic-production.imgix.net/uploads/media_library/93051dee75af4ff526c7b51af9e13001.png?h=70"
                   alt="Pobierz z Google Play" loading="lazy">
            </a>
          </p>
        </div>
      </div>

      <!-- Legal Info -->
      <small class="m-footer-info">
        <span class="m-footer-info__terms">
          <a href="/terms" class="m-footer__link" rel="nofollow">Regulaminy</a> |
          <a href="/privacy-policy" class="m-footer__link" rel="nofollow">Polityka prywatności</a> |
          <a href="#" role="button" data-cc="show-preferencesModal"
             class="m-footer__link" rel="nofollow">Ustawienia ciasteczek</a> |
          <a href="/zgody-marketingowe" class="m-footer__link" rel="nofollow">Zgody marketingowe</a> |
          <a href="/accessibility-statement" class="m-footer__link" rel="nofollow">Deklaracja dostępności</a> |
          <a href="/admin" class="m-footer__link" rel="nofollow">Panel Restauratora</a>
        </span>
      </small>
    </div>
  </footer>

  <!-- ===== SVG Icons Placeholder ===== -->
  <svg xmlns="http://www.w3.org/2000/svg" style="display: none;" class="svg-icons">
    <!-- your <symbol> icons go here -->
  </svg>
</body>
</html>
